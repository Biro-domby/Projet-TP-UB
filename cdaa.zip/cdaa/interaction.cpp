#include "interaction.h"
#include <string>
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>

//constructeurs

Interaction::Interaction(){
    Date date;
    GestionTag tags;

    Date* d = new Date();
    d->setDHCourante();
    setDate(*d);

    delete d;
}

Interaction::Interaction(const Date & t, const std::string & c)
{
    Date date;
    this -> setDate(t);
    this -> setContenu(c);
    GestionTag tags;
}


Interaction::Interaction(const std::string & c)
{
    Date date;
    Date* d = new Date();
    d->setDHCourante();
    setDate(*d);

    delete d;
    this -> setContenu(c);
    GestionTag tags;
}

//destructeur
Interaction::~Interaction()
{}

//assesseurs
void Interaction::setDate(const Date & t)
{    date = t; }

Date Interaction::getDate() const
{   return date; }

void Interaction::setContenu(const std::string & c)
{   contenu = c; }

std::string Interaction::getContenu() const
{   return contenu; }

void Interaction::setTags(const GestionTag & liste)
{    tags = liste; }

GestionTag Interaction::getTags() const
{    return tags; }


//définition des attributs d'après une liste de tâches
void Interaction::initFromString(const std::string & text)
{
    //le contenu de l'intéraction est la chaine entière
    setContenu(text);

    //on crée un stream à partir de la chaine pour pouvoir la parcourir ligne par ligne
    std::istringstream t;
    t.str(text);

    std::string line;

    //pour chaque ligne :
    while (std::getline(t, line)) {
        //on cherche l'expression @todo
        std::size_t found = line.find("@todo");
        //si on la trouve dans la ligne :
        if (found != std::string::npos){
            //on récupère la chaine après "@todo"
            std::string tache = line.substr(found+6,line.npos);
            //on recherche dans cette chaine l'expression "@date"
            found = tache.find("@date");
            //si on trouve "@date"
            if (found != std::string::npos){
                //on récupère chaque parties de la date !
                std::string date = tache.substr(found+6, tache.npos);
                tache = tache.substr(0, found);
                found = date.find("/");
                //le jour
                int j = std::stoi(date.substr(0,found));
                date = date.substr(found+1, date.npos);
                found = date.find("/");
                //le mois
                int m = std::stoi(date.substr(0,found));
                //l'année
                int a = std::stoi(date.substr(found+1, date.npos));
                //on crée un tag à partir de ces informations
                Tag tag(tache, Date(j,m,a));
                //on l'ajoute à la liste de tags
                tags.addTag(tag);
            }
            else{ //sinon, on a pas de "@date"
                //on crée un tag à la date courante
                Date* d = new Date();
                d->setDHCourante();
                setDate(*d);
                Tag tag(tache,*d);
                delete d;
                tags.addTag(tag);
            }
        }
    }
}


//fonctions d'affichages

std::string Interaction::toString() const
{
    std::string s = "INTERACTION :\n"+ getDate().toStringDate() + "\nContenu :\n" + getContenu() + "\nTags associés :\n" + getTags().toString();
    return s;
}

std::string Interaction::toItemTxt() //pour l'affichage dans les QListWidget
{
    std::string s = getDate().toStringDateAbb() + " :\n" + getContenu();
    return s;
}

std::ostream& operator<<(std::ostream & os, const Interaction & i)
{
    os << i.getDate().toStringDate()<<"\n" << " "<<i.getContenu()<<"\n+Tags associés :\n"<<i.getTags();
    return os;
}

//définition des opérateurs de comparaison

bool Interaction::operator==(const Interaction & i)
{   //deux intéractions sont égales si les attributs date et contenu sont égaux
    return (this->getDate() == i.getDate() && this->getContenu() == i.getContenu());
}

//pour les opérateurs >, <, >= et <=, on compare simplement les dates
//ces méthodes sont utilisées pour le tri des intéractions par ordre décroissant d'urgence
bool Interaction::operator>(const Interaction & i)
{
    return (this->getDate() > i.getDate());
}

bool Interaction::operator<=(const Interaction & i)
{
    return (this->getDate() <= i.getDate());
}

bool Interaction::operator>=(const Interaction & i)
{
    return (this->getDate() >= i.getDate());
}

bool Interaction::operator<(const Interaction & i)
{
    return (this->getDate() > i.getDate());
}
