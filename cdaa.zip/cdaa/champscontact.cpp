#include "champscontact.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QInputDialog>

ChampsContact::ChampsContact(QWidget *parent) : QWidget(parent)
{

    QHBoxLayout * nomLayout = new QHBoxLayout();
    lNom = new QLabel("Nom :", this);
    dNom = new QInputDialog(this);

    nomLayout -> addWidget(lNom);
    nomLayout -> addWidget(dNom);


    QHBoxLayout * prenomLayout = new QHBoxLayout();
    lPrenom = new QLabel("Prénom :", this);
    dPrenom = new QInputDialog(this);

    prenomLayout -> addWidget(lPrenom);
    prenomLayout -> addWidget(dPrenom);


    QHBoxLayout * entreLayout = new QHBoxLayout();
    lEntreprise = new QLabel("Entreprise :", this);
    dEntreprise = new QInputDialog(this);

    entreLayout -> addWidget(lEntreprise);
    entreLayout -> addWidget(dEntreprise);


    QHBoxLayout * photoLayout = new QHBoxLayout();
    lPhoto = new QLabel("URI photo :", this);
    dPhoto = new QInputDialog(this);

    photoLayout -> addWidget(lPhoto);
    photoLayout -> addWidget(dPhoto);


    QHBoxLayout * mailLayout = new QHBoxLayout();
    lEmail = new QLabel("Adresse e-mail :", this);
    dEmail = new QInputDialog(this);

    mailLayout -> addWidget(lEmail);
    mailLayout -> addWidget(dEmail);


    QHBoxLayout * dateLayout = new QHBoxLayout();
    lDate = new QLabel("Adresse e-mail :", this);
    dDate = new QInputDialog(this);

    dateLayout -> addWidget(lDate);
    dateLayout -> addWidget(dDate);


    QVBoxLayout * contactLayout = new QVBoxLayout();
    contactLayout -> addLayout(nomLayout);
    contactLayout -> addLayout(prenomLayout);
    contactLayout -> addLayout(entreLayout);
    contactLayout -> addLayout(photoLayout);
    contactLayout -> addLayout(mailLayout);
    contactLayout -> addLayout(dateLayout);

    setLayout(contactLayout);

}
