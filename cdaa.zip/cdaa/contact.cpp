#include <ctime>
#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>

//constructeurs

Contact::Contact()
{   //par défaut, tout est vide
    setNom("");
    setPrenom("");
    setEntreprise("");
    setMail(" @ ");
    setUriPhoto(" ");

    Date dateCreation;
    Date derniereModif;

    Date* d = new Date();
    d->setDHCourante();
    setDernModif(*d);
    setDate(*d);

    delete d;

    std::list<unsigned> telephone;
    GestionInter listInteractions;
}

Contact::Contact(const std::string nom, const std::string prenom, const std::string entreprise)
{   //on initialise seulement les nom, prénom et entreprise
    setNom(nom);
    setPrenom(prenom);
    setEntreprise(entreprise);
    setMail(" @ ");
    setUriPhoto(" ");

    Date dateCreation;
    Date derniereModif;

    Date* d = new Date();
    d->setDHCourante();
    setDernModif(*d);
    setDate(*d);

    delete d;

    std::list<unsigned> telephone;
    GestionInter listInteractions;
}

Contact::Contact(std::string s) //les valeurs de nom, prenom et entreprise sont extraites d'une chaine de caractère de forme "NOM PRENOM, ENTREPRISE"
{
    std::size_t found = s.find(" ");
    setNom(s.substr(0,found));
    s = s.substr(found+1);

    found = s.find(", ");
    setPrenom(s.substr(0,found));
    s = s.substr(found+2);

    setEntreprise(s);

    Date dateCreation;
    Date derniereModif;

    Date* d = new Date();
    d->setDHCourante();
    setDernModif(*d);
    setDate(*d);

    delete d;

    std::list<unsigned> telephone;
    GestionInter listInteractions;
}

void Contact::initFromString(std::string s) //idem
{
    std::size_t found = s.find(" ");
    setNom(s.substr(0,found));
    s = s.substr(found+1);

    found = s.find(", ");
    setPrenom(s.substr(0,found));
    s = s.substr(found+2);

    setEntreprise(s);
}

//destructeur
Contact::~Contact()
{
    telephone.clear();
}

//assesseurs
void Contact::setNom(const std::string s)
{   nom = s;
    derniereModif.setDHCourante();
}

std::string Contact::getNom() const
{   return nom; }

void Contact::setPrenom(const std::string s)
{   prenom = s;
    derniereModif.setDHCourante();
}

std::string Contact::getPrenom() const
{   return prenom; }

void Contact::setEntreprise(const std::string s)
{   entreprise = s;
    derniereModif.setDHCourante();
}

std::string Contact::getEntreprise() const
{   return entreprise; }

void Contact::setMail(const std::string s)
{   mail = s;
    derniereModif.setDHCourante();
}

std::string Contact::getMail() const
{   return mail; }

void Contact::setUriPhoto(const std::string s)
{   uriPhoto = s;
    derniereModif.setDHCourante();
}

std::string Contact::getUriPhoto() const
{   return uriPhoto; }

void Contact::setTelephone(const std::list<unsigned int> l)
{    telephone = l;
     derniereModif.setDHCourante();
}

void Contact::setTelephoneFromStd(const std::string str)
{
    //pour remplir la liste telephone d'après une chaine de caractères
    std::list<unsigned int> t;
    int l = str.length();
    for(int i = 0; i < l; i++)
    {
        std::string c = str.substr(i, 1);
        int j = std::stoi(c);
        t.push_back(j);
    }
    telephone = t;
    derniereModif.setDHCourante();
}

std::list<unsigned> Contact::getTelephone() const
{   return telephone; }

std::string Contact::getStTelephone() const
{
    //on retourne le téléphone sous forme de chaine
    std::string s =""; // on crée une chaine vide
    for (auto&& i : telephone){
        //on parcourt la liste telephone
        s.append(std::to_string(i)); //on concatène chaque int ensemble
    }
    //on retourne la chaine
   return s;
}

void Contact::setDate(const Date & t)
{    dateCreation = t; }

Date Contact::getDate() const
{   return dateCreation; }

void Contact::setDernModif(const Date & t)
{    derniereModif = t; }

Date Contact::getDernModif() const
{   return derniereModif; }

bool Contact::isNull()
{
    if(getNom()=="" && getPrenom()=="" && getEntreprise()=="")
        return true;

    return false;
}

//operateur de comparaison

//utilisé pour supprimer les contacts
bool Contact::operator==(const Contact & c)
{
    return (this->getNom()==c.getNom() && this->getPrenom() == c.getPrenom());
}

//affichage
std::ostream& operator<<(std::ostream & os, const Contact & c)
{
    os << "\nNom : " <<c.getNom() << " | Prénom : " << c.getPrenom() << "\nEntreprise : " << c.getEntreprise() << "\nN° Tel : " << c.getStTelephone();
    os<<"\nCréé le : "<<c.getDate().toStringDateH() << "\n";

    if(c.getDernModif() != c.getDate())//si la date de modification est différente de la date de création
        os<<"Modifié pour la dernière fois le : "<<c.getDernModif().toStringDateH();

    return os;
}

std::string Contact::toString()
{
    std::string s;
    s+= "Nom : " + getNom() + " | Prénom : " + getPrenom() + "\nEntreprise : " + getEntreprise() + "\nN° Tel : " + getStTelephone();
    s+= "Créé le :" + getDate().toStringDateH() + "\n";
    return s;
}

std::string Contact::toItemTxt()//pour l'affichage dans les QListWidget
{
    std::string s = getNom() + " " + getPrenom() + ", " + getEntreprise();
    return s;
}
