#ifndef CREACONTACT_H
#define CREACONTACT_H

#include <QWidget>

#include "contact.h"
#include <QLabel>

namespace Ui {
class creaContact;
}

class creaContact : public QWidget
{
    Q_OBJECT

public:
    explicit creaContact(QWidget *parent = nullptr);
    ~creaContact();

    void champsObli();
    void ajoutContact();

private slots:
    void on_bValider_clicked();

private:
    Ui::creaContact *ui;
    //contact créé
    Contact* c;

signals:
    //ajout du contact dans la BDD
    void sigAddContact(Contact&);
    void razWidgetCentral();

};

#endif // CREACONTACT_H
