#ifndef QSQLDATA_H
#define QSQLDATA_H

#include <QObject>
#include <QVariant>
#include <QtSql/QSqlDatabase>
#include <QStringList>
#include <QStringList>
#include <list>
#include <gestioncontact.h>
#include <contact.h>
#include <gestiontag.h>
#include <gestioninter.h>
#include <tag.h>
#include <interaction.h>

#include "contact.h"
#include "interaction.h"
#include "formulairerecherche.h"

class QSQLData : public QObject
{
    Q_OBJECT

private:
    QSqlDatabase db;

    bool dbOuverte;

    bool connectDB(const QString &);
    void closeDB();
    void isDBOpen(bool&);

    //void getAllContacts(std::list<Contact> &) const;

    bool createContact(const Contact &) const;
    bool deleteContact(const Contact &) const;
    bool updateContact(const Contact &, const Contact &) const;

    bool searchContact(formulaireRecherche&) const;
    bool searchTag(formulaireRecherche&) const;
    bool searchTodos(formulaireRecherche&) const;
    bool searchInter(formulaireRecherche&) const;

    bool createInter(const Interaction &, const Contact &) const;
    bool createTag(const Interaction&) const;
    bool deleteTag(const Tag&) const;
    bool getTags(const Contact &) const;
    bool createAssocTI(int) const;


public:
    explicit QSQLData(QObject *parent = nullptr);
    ~QSQLData();
     GestionContact* getStdListContacts();
     Contact* getContact(std::string);

signals:
    void jobDonc(unsigned);
    void finMajBDD()const;
    void envoieResultatsRechercheContacts(GestionContact*) const;
    void pasDeResulRechercheContacts() const;
    void envoieResultatsTodos(GestionTag*) const;
    void pasDeResulRechercheTodos() const;
    void envoieResultatsInter(GestionInter*) const;
    void pasDeResulRechercheInter() const;
    void envoieListTags(GestionTag*) const;
    void envoieResultatsTags(GestionTag*) const;
    void pasDeResulRechercheTags() const;

public slots:
    void bddCreateContact(Contact&);
    void bddDeleteContact(Contact&);
    void bddUpdateContact(Contact&, Contact&);
    void bddCreateInter(Interaction&, Contact&);
    void bddDeleteTag(Tag&);

    void bddRechercheContacts(formulaireRecherche&);
    void bddRechercheTags(formulaireRecherche&);
    void bddRechercheTodos(formulaireRecherche&);
    void bddRechercheInter(formulaireRecherche&);

    void bddGetTags(Contact&);
    void isOpen(bool &);
};

#endif // QSQLDATA_H
