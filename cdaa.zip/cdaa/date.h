#ifndef DATE_H
#define DATE_H

#include <ctime>
#include <string>

class Date
{
private:
    //tm * date;
    int an;
    int mois;
    int jour;
    int heure;
    int min;
    int sec;

public:
    //constructeur
    Date();
    Date(const int & j, const int & m, const int & a);
    Date(const int & j, const int & m, const int & a, const int & h, const int & min, const int & s);
    Date(std::string);

    //assesseurs
    int getJour() const;
    int getMois() const;
    int getAnnee() const;
    int getHeure() const;
    int getMin() const;
    int getSec() const;

    void setJour(const int &);
    void setMois(const int &);
    void setAnnee(const int &);
    void setHeure(const int &);
    void setMin(const int &);
    void setSec(const int &);

    void setDate(const int & j, const int & m, const int & a);
    void setDateEtHeure(const int & j, const int & m, const int & a, const int & h, const int & min, const int & s);

    void setDateCourante();
    void setDHCourante();

    void setDateVide();
    void setDHVide();

    //ces méthodes retournent les date ou  date et heure courantes sous forme d'instance de Date
    Date dateCourante() const;
    Date DHCourante() const;

    bool isNull() const;
    void setToNull();

    //méthode d'affichage
    std::string toStringDate();
    std::string toStringDateAbb();
    std::string toStringDateH();

    //opérateurs de comparaison
    bool operator==(const Date &);
    bool operator!=(const Date &);

    bool operator>(const Date & d);
    bool operator>=(const Date & d);
    bool operator<(const Date & d);
    bool operator<=(const Date & d);

};

#endif // DATE_H
