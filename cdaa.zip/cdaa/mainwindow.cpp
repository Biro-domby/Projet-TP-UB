#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qgridlayout.h"
#include "creacontact.h"
#include "creainter.h"
#include "QMessageBox"
#include "interaction.h"
#include "contact.h"
#include "qsqldata.h"
#include <stdio.h>
#include <iostream>
#include <QMessageBox>
#include <QPixmap>
#include <QPicture>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //remplissage de la liste de contacts
    listeContacts = interfaceSQL.getStdListContacts();
    ui->listWidget->addItems(listeContacts->toItemList());
    //initialisation du nombre de contacts
    std::string nb = "Nombre de contacts : " + std::to_string(listeContacts->getContactList().size());
    ui->lNbContact->setText(QString::fromStdString(nb));

    //initialisation de l'image de contact
    im.load("noPhoto.jpg");
    ui->lImage->setPixmap(im);
    ui->lImage->setScaledContents(true);

    //signaux pour la suppression d'un contact
    connect(this, SIGNAL(suppContactSelect(Contact&)), &interfaceSQL, SLOT(bddDeleteContact(Contact&)));
    connect(&interfaceSQL, SIGNAL(finMajBDD()), this, SLOT(razList()));

    //signaux pour le remplissage, la recherche et la suppression dans la liste de tags du contact sélectionné
    connect(this, SIGNAL(remplirListTags(Contact&)), &interfaceSQL, SLOT(bddGetTags(Contact&)));
    connect(&interfaceSQL, SIGNAL(envoieListTags(GestionTag*)), this, SLOT(listeTodosContactSelect(GestionTag*)));
    connect(this, SIGNAL(suppTagSelect(Tag&)), &interfaceSQL, SLOT(bddDeleteTag(Tag&)));
    connect(this, SIGNAL(chercherTags(formulaireRecherche&)), &interfaceSQL, SLOT(bddRechercheTags(formulaireRecherche&)));
    connect(&interfaceSQL, SIGNAL(envoieResultatsTags(GestionTag*)), this, SLOT(listeResultatsTag(GestionTag*)));
    connect(&interfaceSQL, SIGNAL(pasDeResulRechercheTags()), this, SLOT(aucunResultatTag()));
}

MainWindow::~MainWindow()
{}


//mise à jour de l'affichage

void MainWindow::majAff()
{
    majList();
    majDescr();
}

//maj de la description du contact sélectionné
void MainWindow::majDescr()
{
    //remplissage des champs
    ui->leNom->setText(QString::fromStdString(contactSelec->getNom()));
    ui->lePrenom->setText(QString::fromStdString(contactSelec->getPrenom()));
    ui->leEntreprise->setText(QString::fromStdString(contactSelec->getEntreprise()));
    ui->leMail->setText(QString::fromStdString(contactSelec->getMail()));
    ui->leTel->setText(QString::fromStdString(contactSelec->getStTelephone()));
    ui->lePhoto->setText(QString::fromStdString(contactSelec->getUriPhoto()));
    ui->leDateCrea->setText(QString::fromStdString(contactSelec->getDate().toStringDateAbb()));
    ui->leDateModif->setText(QString::fromStdString(contactSelec->getDernModif().toStringDateAbb()));

    //affichage de la photo
    if(contactSelec->getUriPhoto()=="")
        im.load("noPhoto.jpg");
    else
        im.load(QString::fromStdString(contactSelec->getUriPhoto()));

    ui->lImage->setPixmap(im);
    ui->lImage->setScaledContents(true);

    //vidage de la liste de todos du contact affiché
    razListTags();
    //mise à jour de la liste de todos
    majListTags();
}

//mise à jour de la liste des contact
void MainWindow::majList()
{
    //on efface la liste
    ui->listWidget->clear();
    //on récupère la liste
    listeContacts = interfaceSQL.getStdListContacts();
    //on ajoute chaque contact à la liste
    ui->listWidget->addItems(listeContacts->toItemList());
    //mise à jour du nombre de contact
    std::string nb = "Nombre de contacts : " + std::to_string(listeContacts->getContactList().size());
    ui->lNbContact->setText(QString::fromStdString(nb));
}

//mise à jour de la liste des todos du contact sélectionné
void MainWindow::majListTags()
{
    //on vide la liste
    ui->listTags->clear();
    //on demande la liste des tags
    emit remplirListTags(*contactSelec);

    ui->cbDateTag->setCheckState(Qt::Unchecked);
}

//remise à zéro de l'affichage

//remise à zéro de la description du contact sélectionné
void MainWindow::razDescr()
{
    //on vide tous les champs
    ui->leNom->clear();
    ui->lePrenom->clear();
    ui->leEntreprise->clear();
    ui->leMail->clear();
    ui->leTel->clear();
    ui->lePhoto->clear();
    ui->leDateCrea->clear();
    ui->leDateModif->clear();
    ui->listWidget->clearSelection();
    //on met la photo par défaut
    im.load("noPhoto.jpg");
    ui->lImage->setPixmap(im);
    ui->lImage->setScaledContents(true);
    //on remet à zéro la la liste des tags du contact sélectionné
    razListTags();
}

//remise à zéro de la liste de contacts
void MainWindow::razList()
{
    contactSelec = new Contact();
    tagSelec= new Tag();
    majAff();
    razDescr();
}

//remise à zéro de la liste des todos du contact sélectionné
void MainWindow::razListTags()
{
    //on vide la liste
    ui->listTags->clear();
    //on grise les boutons, checkbox et dateEdit du filtrage
    ui->bSupprTodo->setEnabled(false);
    ui->cbIntervalTag->setEnabled(false);
    ui->deTag1->setEnabled(false);
    ui->deTag2->setEnabled(false);
}

//remise à zéro des filtres des todos du contact sélectionné
void MainWindow::razFiltreTags()
{
    //on grise et décoche les dateEdit, boutons et checkbox
    ui->deTag1->setEnabled(false);
    ui->deTag2->setEnabled(false);
    ui->bFiltrer->setEnabled(false);
    ui->cbIntervalTag->setCheckState(Qt::Unchecked);
    ui->cbIntervalTag->setEnabled(false);
    ui->cbDateTag->setCheckState(Qt::Unchecked);
}

//OUVERTURE DES FENETRES

//Ouverture d'une fenêtre de création de contact
void MainWindow::on_ajoutContact_triggered()
{
        creaContact * wContact = new creaContact();

        //signaux/slots
        connect(wContact, SIGNAL(sigAddContact(Contact&)), &interfaceSQL, SLOT(bddCreateContact(Contact&)));
        connect(wContact, SIGNAL(razWidgetCentral()), this, SLOT(majList()));

        wContact->show();
}

//Ouverture d'une fenêtre de création d'intéraction
void MainWindow::on_ajoutInter_triggered()
{
        creaInter * wInter = new creaInter();

        //signaux/slots
        connect(wInter, SIGNAL(sigAddInter(Interaction&,Contact&)), &interfaceSQL, SLOT(bddCreateInter(Interaction&,Contact&)));
        connect(wInter, SIGNAL(majAffInter()), this, SLOT(majListTags()));

        //remplissage de la comboBox
        wInter->setQstList(interfaceSQL.getStdListContacts()->toItemList());

        wInter->show();
}

//Ouverture d'une fenêtre de recherche d'un contact
void MainWindow::on_chercherContact_triggered()
{
    chercherContact * wSearchContact = new chercherContact();

    //signaux/slots
    connect(wSearchContact, SIGNAL(envoiRecherche(formulaireRecherche&)), &interfaceSQL, SLOT(bddRechercheContacts(formulaireRecherche&)));
    connect(&interfaceSQL, SIGNAL(pasDeResulRechercheContacts()), wSearchContact, SLOT(aucunResultat()));
    connect(&interfaceSQL, SIGNAL(envoieResultatsRechercheContacts(GestionContact*)), wSearchContact, SLOT(listeResultats(GestionContact*)));
    connect(wSearchContact, SIGNAL(retourneContactSelec(Contact*)), this, SLOT(contactSelectFromSearch(Contact*)));

    wSearchContact->show();
}

//Fermeture de la fenêtre de recherche d'un contact par sélection
void MainWindow::contactSelectFromSearch(Contact * c)
{
    //le contact sélectionné est le contact retourné
    contactSelec = interfaceSQL.getContact(c->toItemTxt());
    //mise à jour de sa description
    majDescr();
}

//Ouverture d'une fenêtre de recherche de tag / d'intéraction
void MainWindow::on_chercherTagsInter_triggered()
{
    visuInterTodo * wVisuInterTodo = new visuInterTodo();

    //remplissage de la comboBox avec la liste des contacts
    wVisuInterTodo->setQstList(interfaceSQL.getStdListContacts()->toItemList());

    //signaux/slots
    connect(wVisuInterTodo, SIGNAL(envoiRechercheTodo(formulaireRecherche&)), &interfaceSQL, SLOT(bddRechercheTodos(formulaireRecherche&)));
    connect(&interfaceSQL, SIGNAL(envoieResultatsTodos(GestionTag*)), wVisuInterTodo, SLOT(listeResultatsTodos(GestionTag*)));
    connect(wVisuInterTodo, SIGNAL(envoiRechercheInter(formulaireRecherche&)), &interfaceSQL, SLOT(bddRechercheInter(formulaireRecherche&)));
    connect(&interfaceSQL, SIGNAL(envoieResultatsInter(GestionInter*)), wVisuInterTodo, SLOT(listeResultatsInter(GestionInter*)));
    connect(&interfaceSQL, SIGNAL(pasDeResulRechercheTodos()), wVisuInterTodo, SLOT(aucunResultatTodo()));
    connect(&interfaceSQL, SIGNAL(pasDeResulRechercheInter()), wVisuInterTodo, SLOT(aucunResultatInter()));

    wVisuInterTodo->show();
}


//AFFICHAGE
//clic sur un contact de la liste
void MainWindow::on_listWidget_itemClicked(QListWidgetItem *item)
{
    //le contact est mis en contact sélectionné
    contactSelec = interfaceSQL.getContact(item->text().toStdString());
    //on met à jour la description
    majDescr();
    razFiltreTags();
}

//Appui sur les boutons radios de tri de la liste de contact
void MainWindow::on_tAlphC_clicked()
{    ui->listWidget->sortItems(Qt::AscendingOrder);  }

void MainWindow::on_tALphD_clicked()
{    ui->listWidget->sortItems(Qt::DescendingOrder);  }


//modification du contact sélectionné
void MainWindow::on_bModif_clicked()
{
    if(ui->listWidget->selectedItems().length()!=0) //on vérifie qu'un contact est sélectioné
    {   //ouverture de la fenêtre
        editContact * wEditContact = new editContact();
        //siganux/slots
        connect(this, SIGNAL(remplirEditContact(Contact&)), wEditContact, SLOT(remplir(Contact&)));
        connect(wEditContact, SIGNAL(sigUpdateContact(Contact&,Contact&)), &interfaceSQL, SLOT(bddUpdateContact(Contact&,Contact&)));
        //remplissage des champs du contact
        emit remplirEditContact(*contactSelec);

        wEditContact->show();
    }
}

//suppression du contact sélectionné
void MainWindow::on_bSupprimer_clicked()
{
    if(ui->listWidget->selectedItems().length()!=0) //on vérifie qu'un contact est bien sélectionné
    {
        //on vérifie le consentement de l'utilisateur
        QMessageBox msgBox;
        msgBox.setText("Êtes-vous sûr·e de vouloir supprimer ce contact ?");
        msgBox.setStandardButtons(QMessageBox::Cancel | QMessageBox::Yes);
        msgBox.setDefaultButton(QMessageBox::Cancel);
        int ret = msgBox.exec();

        if(ret == QMessageBox::Yes)
        {  //demande de suppression du contact
            emit suppContactSelect(*contactSelec);
            //remise à zéro de la description
            razList();
        }
    }
}


//mise à jour de la liste de todo du contact sélectionné
void MainWindow::listeTodosContactSelect(GestionTag* gt)
{    ui->listTags->addItems(gt->toItemList()); }

//sélection d'un todo de la liste
void MainWindow::on_listTags_itemClicked(QListWidgetItem *)
{    ui->bSupprTodo->setEnabled(true); } //on active le bouton "Supprimer"

//suppression du todo sélectionné
void MainWindow::on_bSupprTodo_clicked()
{
    if(ui->listTags->selectedItems().length()!=0) //on vérifie que le contact est sélectionné
    {
        //on vérifie le consentement de l'utilisateur
        QMessageBox msgBox;
        msgBox.setText("Êtes-vous sûr·e de vouloir supprimer ce @todo ?");
        msgBox.setStandardButtons(QMessageBox::Cancel | QMessageBox::Yes);
        msgBox.setDefaultButton(QMessageBox::Cancel);
        int ret = msgBox.exec();
        //on initialise un tag d'après le texte de l'item sélectionné
        tagSelec = new Tag();
        tagSelec->initFromItemTag(ui->listTags->selectedItems()[0]->text().toStdString());
        if(ret == QMessageBox::Yes)
        {   //on demande la suppression
            emit suppTagSelect(*tagSelec);
            //mise à jour de la liste de tags
            majListTags();
        }
    }
}


//RECHERCHE DANS LA LISTE DE TODOS du contact sélectionné
//Appui sur le filtrage de date des todos
void MainWindow::on_cbDateTag_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //nouvel état : cochée
        ui->deTag1->setEnabled(true);
        ui->bFiltrer->setEnabled(true);
        ui->cbIntervalTag->setEnabled(true);
        break;
    case Qt::Unchecked: //nouvel état : décochée
        ui->deTag1->setEnabled(false);
        ui->bFiltrer->setEnabled(false);
        ui->cbIntervalTag->setEnabled(false);
        majListTags();
        break;
    }
}

//Appui sur la checkbox activation du filtrage de la date par intervalle
void MainWindow::on_cbIntervalTag_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked:
        ui->deTag2->setEnabled(true);
        break;
    case Qt::Unchecked:
        ui->deTag2->setEnabled(false);
        break;
    }
}

//Appui sur le bouton fitrer
void MainWindow::on_bFiltrer_clicked()
{
    //on crée et remplit un formulaire de recherche d'après l'interface
    rechercheTags = new formulaireRecherche();
    rechercheTags->setContact(*contactSelec);
    rechercheTags->setCrea1(ui->deTag1->date().toString("yyyy-MM-dd").toStdString());
    if(ui->cbIntervalTag->isChecked()==false)
        rechercheTags->setNullCrea2();
    else
        rechercheTags->setCrea2(ui->deTag2->date().toString("yyyy-MM-dd").toStdString());

    //on demande la liste de résultats correspondant
    emit chercherTags(*rechercheTags);
}

//Résultat de la recherche
//si la recherche ne renvoit aucun résultat :
void MainWindow::aucunResultatTag()
{
    razListTags();

    //information à l'utilsateur
    QMessageBox msgBox;
    msgBox.setText("Il n'y a pas de @todo correspondants à ces filtres.");
    msgBox.exec();

    majListTags();
}

//si la rehcerche retourne des résultats :
void MainWindow::listeResultatsTag(GestionTag *gt)
{
    //on les affiche dans la liste de todo
    razListTags();
    ui->listTags->addItems(gt->toItemList());
}




