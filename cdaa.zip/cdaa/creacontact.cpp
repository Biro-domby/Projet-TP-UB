#include "creacontact.h"
#include "ui_creaContact.h"
#include "QDebug"
#include <iostream>
#include <unistd.h>
#include <string>
#include <sstream>
#include <ctime>
#include "contact.h"
#include <QLabel>
#include <QMessageBox>

creaContact::creaContact(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::creaContact)
{
    ui->setupUi(this);
    c = new Contact();
}
creaContact::~creaContact(){
    delete ui;
}

//Appui sur le bouton Valider :
void creaContact::on_bValider_clicked()
{
    //Si tous les champs sont remplis :
    if(!ui->lNom->text().isEmpty() && !ui->lPrenom->text().isEmpty() && !ui->lEntreprise->text().isEmpty())
    {
        //Ajout du contact à la BDD
        ajoutContact();
    }
    //Sinon :
    else
    {
        champsObli();
    }
}

//Affichage d'un message à l'utilisateur pour lui demander de remplir tous les champs
void creaContact::champsObli()
{
    QMessageBox msgBox;
    msgBox.setText("Erreur : Le nom, prénom et entreprise sont des champs obligatoires.");
    msgBox.exec();
}

//Envoi à la BDD :
void creaContact::ajoutContact()
{
    //Initialisation du contact d'après les champs du formulaire :
    c->setNom(ui->lNom->text().toStdString());
    c->setPrenom(ui->lPrenom->text().toStdString());
    c->setEntreprise(ui->lEntreprise->text().toStdString());

    //envoi de la demande à la BDD
    emit sigAddContact(*c);
    emit razWidgetCentral();
    //fermeture
    close();
}
