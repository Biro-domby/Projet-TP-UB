#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>
#include <iostream>


//constructeurs

GestionTag::GestionTag()
{    std::list<Tag> tagList; }

GestionTag::GestionTag(std::list<Tag> liste)
{
    std::list<Tag> tagList;
    setTagList(liste);
}


//destructeur
GestionTag::~GestionTag()
{    tagList.clear(); }


//assesseurs

void GestionTag::setTagList(std::list<Tag> liste)
{    tagList = liste; }

std::list<Tag> GestionTag::getTagList()
{    return tagList; }


//gestion des tags de la liste

void GestionTag::addTag(Tag t) //ajout d'un tag à la liste
{    tagList.push_back(t); }


//affichage

std::string GestionTag::toString() const
{
    std::string s;
    for (auto&& i : tagList){
        s += i.toString() + "\n";
    }
    return s;
}

QStringList GestionTag::toItemList() //retourne la liste de tags sous forme de QStringList, pour l'affichage dans les QListWidget
{
    QStringList l;
    for (auto&& i : tagList){
        QString s;
        s = QString::fromStdString(i.toItemTxt());
        l<<s;
    }
    return l;
}



std::ostream& operator<<(std::ostream & os, const GestionTag & gsTag)
{
    for (auto&& i : gsTag.tagList){
        os << i << "\n";
    }
    return os;
}
