#include <QApplication>
#include <iostream>
#include <unistd.h>
#include <string>
#include <sstream>
#include <ctime>
#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>
#include <creacontact.h>
#include <qsqldata.h>
#include <creainter.h>
#include <QStringList>
#include <QMainWindow>
#include <mainwindow.h>
#include <qlist.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;
    w.show();

    /*
    std::list<unsigned> telephone = {0,1,2,3,4,5,6,7,8,9};
    std::string s =""; // on crée une chaine vide
    for (auto&& i : telephone){
        //on parcourt la liste telephone
        s.append(std::to_string(i)); //on concatène chaque int ensemble
    }

    std::cout<<s<<std::endl;

    std::list<unsigned int> t;

    int l = s.length();
    for(int i = 0; i < l; i++)
    {
        std::string c = s.substr(i, 1);
        int j = std::stoi(c);
        t.push_back(j);
    }

    telephone = t;

    s =""; // on crée une chaine vide
    for (auto&& i : telephone){
        //on parcourt la liste telephone
        s.append(std::to_string(i)); //on concatène chaque int ensemble
    }

    std::cout<<s<<std::endl;
    */

    /*
    //Création de contacts
    Contact C1("Fuhrmann", "Finley", "A");
    Contact C2("Van Baarle", "Reuven", "A");
    Contact C3("Chaput", "Hiltraud", "B");
    Contact C4("Clemens", "Chand", "C");
    Contact C5("MacNeil", "Vanda", "D");

    //ajout à une classe GestionContact
    GestionContact gs;
    gs.addContact(C1);
    gs.addContact(C2);
    gs.addContact(C3);
    gs.addContact(C4);
    gs.addContact(C5);

    //affichage des contacts
    std::cout<<gs<<std::endl;

    //on enlève un contact
    std::cout<<"Supression de CLEMENS CHAND\n"<<std::endl;
    gs.removeContact("Clemens", "Chand");

    //affichage après suppression :
    std::cout<<gs<<std::endl;

    //affichage du contact 2
    std::cout<<"\n\n"<<C2<<std::endl;

    std::cout<<"\n\n**Modification du contact**\n\n"<<std::endl;

    //on attend 5 secondes pour voir la différence dans la date de modification
    sleep(5);
    //modification du contact
    C2.setEntreprise("X");

    //affichage du contact modifié
    std::cout<<C2<<"\n\n"<<std::endl;


    //démonstration de la création d'une Intéraction d'après une chaine

    std::string f = "rdv aujourd'hui par tél., RAS.\n@todo Rappeler @date 16/10/2021\n@todo Confirmer commande n°xyz";

    Interaction I;
    I.initFromString(f);

    //affichage de l'intéraction
    std::cout<<"\n\n"<<I<<"\n"<<std::endl;
    //affichage de la liste des tags créés
    std::cout<<I.getTags()<<"\n\n"<<std::endl;


    //démonstration du tri des dates :

    //on crée différentes dates
    Interaction i1(Date(1,10,2022), "Contenu de i1");
    Interaction i2(Date(13,12,2001), "Contenu de i2");
    Interaction i3(Date(27,10,2021), "Contenu de i3");
    Interaction i4(Date(13,12,2021), "Contenu de i4");
    Interaction i5(Date(16,2,2022), "Contenu de i5");

    GestionInter gsInter;

    //on les ajoute à une instance de Gestion Inter
    gsInter.addInter(i1);
    gsInter.addInter(i2);
    gsInter.addInter(i3);
    gsInter.addInter(i4);
    gsInter.addInter(i5);

    //affichage des dates non-triées
    std::cout<<"**Dates non triées**\n"<<std::endl;
    std::cout<<gsInter<<std::endl;

    //tri
    gsInter.trier();

    //affichage des dates triées
    std::cout<<"**Dates triées**\n"<<std::endl;
    std::cout<<gsInter<<std::endl;
    */

    return a.exec();
}
