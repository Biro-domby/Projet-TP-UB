#include "date.h"
#include <ctime>
#include <qstring.h>
#include <qregexp.h>
#include <qstringlist.h>

//constucteurs

Date::Date()
{
    an=0;
    mois=0;
    jour=0;
    heure=0;
    min=0;
    sec=0;
}

Date::Date(const int & j, const int & m, const int & y)
{    setDateEtHeure(j,m,y,0,0,0);}

Date::Date(const int & j, const int & m, const int & a, const int & h, const int & mn, const int & s)
{    setDateEtHeure(j,m,a,h,mn,s);}

//initialise la date d'après une chaine de type "yyyy-mm-dd"
Date::Date(std::string s){
    QRegExp rx("(\\d+)");
    QString str = QString::fromStdString(s);
    QStringList list;
    int pos = 0;

    while ((pos = rx.indexIn(str, pos)) != -1) {
        list << rx.cap(1);
        pos += rx.matchedLength();
    }

    setDateEtHeure(list[2].toInt(),list[1].toInt(),list[0].toInt(),0,0,0);
}


//assesseurs

void Date::setJour(const int & n)
{    jour = n;}

void Date::setMois(const int & n)
{    mois = n;}

void Date::setAnnee(const int & n)
{    an = n;}

void Date::setHeure(const int & n)
{    heure = n;}

void Date::setMin(const int & n)
{    min = n;}

void Date::setSec(const int & n)
{    sec = n;}

int Date::getJour() const
{   return jour;}

int Date::getMois() const
{   return mois;}

int Date::getAnnee() const
{   return an;}

int Date::getHeure() const
{   return heure;}

int Date::getMin() const
{    return min;}

int Date::getSec() const
{   return sec;}


void Date::setDate(const int & j,const int & m, const int & y)
{
    an=y;
    mois=m;
    jour=j;
}


void Date::setDateEtHeure(const int & j, const int & m, const int & a, const int & h, const int & mn, const int & s)
{
    an=a;
    mois=m;
    jour=j;
    heure=h;
    min=mn;
    sec=s;
}

//met l'instance de Date à la date du jour
void Date::setDateCourante()
{
    time_t tn = time(0);
    tm* tdate = localtime(& tn);
    setDate(tdate->tm_mday, tdate->tm_mon+1, tdate->tm_year+1900);
}

//met l'instance de Date à la date et l'heure courante
void Date::setDHCourante()
{
    time_t tn = time(0);
    tm* tdate = localtime(& tn);
    setDateEtHeure(tdate->tm_mday, tdate->tm_mon+1, tdate->tm_year+1900, tdate->tm_hour, tdate->tm_min, tdate->tm_sec);
}

void Date::setDateVide()
{   setDate(0,0,0); }

void Date::setDHVide()
{   setDateEtHeure(0,0,0,0,0,0);}

//construit une instance de Date à la date courante
Date Date::dateCourante() const
{
    Date d;
    d.setDateCourante();
    return d;
}

//construit une instance de Date à la date et heure courante
Date Date::DHCourante() const
{
    Date d;
    d.setDHCourante();
    return d;
}

//retourne vrai si le jour, l'annee et le mois sont à 0
bool Date::isNull() const
{
    if(getJour()==0 && getAnnee()==0 && getMois()==0)
        return true;
    else
        return false;
}

//méthodes d'affichage

//donne la date en toutes lettres
std::string Date::toStringDate()
{
    const char * m[] = {"", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"};

    std::string s;

    s+= std::to_string(jour) ;
    s+= " ";
    s+=m[mois];
    s+= " ";
    s+= std::to_string(an);

    return s;
}

//donne la date en toute lettres et l'heure
std::string Date::toStringDateH(){

    std::string s = this->toStringDate();
    s+= " " ;
    s+= std::to_string(heure);
    s+= ":" ;
    s+= std::to_string(min);
    s+= ":";
    s+= std::to_string(sec);

    return s;
}

//donne la date sous la forme "YYYY-MM-DD"
std::string Date::toStringDateAbb(){
    std::string s ="";
    s+= std::to_string(an);
    s+= "-";
    if(mois>=10)
        s+= std::to_string(mois);
    else
        s+= "0" + std::to_string(mois);
    s+= "-";
    if(jour>=10)
        s+= std::to_string(jour);
    else
        s+= "0" + std::to_string(jour);

    return s;
}


//opérateurs de comparaison

bool Date::operator==(const Date & d)
{
    return (this->getAnnee()==d.getAnnee() && this->getJour() == d.getJour() && this->getMois() == d.getMois()
            && this->getHeure() == d.getHeure() && this->getMin() == d.getMin() && this->getSec() == d.getSec());
}

bool Date::operator!=(const Date & d)
{
    return (!(*this == d));
}

bool Date::operator>(const Date & d)
{
    if(this->getAnnee()<d.getAnnee()) //si l'année de this est plus petite, on retourne faux
        return false;
    else if(this->getAnnee()>d.getAnnee()) //sinon; si l'année de this est plus grande, on retourne vraie
        return true;
    else{ //années égales
         if(this->getMois()<d.getMois())//idem avec les mois
             return false;
         else if(this->getMois()>d.getMois())
             return true;
         else{//mois égaux
             if(this->getJour()<d.getJour())//idem avec les jours
                 return false;
             else if(this->getJour()>d.getJour())
                 return true;
         }
    }
    return false; //si les dates sont égales, on retourne faux
}

bool Date::operator<=(const Date & d)
{
    return(!(*this>d));
}

bool Date::operator>=(const Date & d)
{
    return(!(*this<d));
}

bool Date::operator<(const Date & d)
{
   if(this->getAnnee()>d.getAnnee()) //même fonctionnement que pour l'opérateur >
       return false;
   else if(this->getAnnee()<d.getAnnee())
       return true;
   else{ //années égales
        if(this->getMois()>d.getMois())
            return false;
        else if(this->getMois()<d.getMois())
            return true;
        else{//mois égaux
            if(this->getJour()>d.getJour())
                return false;
            else if(this->getJour()<d.getJour())
                return true;

        }
   }
   return false;
}
