#include "tag.h"
#include <ctime>
#include <iostream>
#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>

//constructeurs


Tag::Tag() //constructeur par défaut
{
    this->contenuTag = " ";
    Date dateTag;

    Date* d = new Date();
    d->setDHCourante();

    this->setDateTag(*d);

    delete d;
}

//constructeur à partir du contenu et de la date
Tag::Tag(const std::string & c, const Date & t)
{
    this -> setDateTag(t);
    this -> setContenuTag(c);
}

//constructeur à partir du contenu
Tag::Tag(const std::string & c)
{
    Date* d = new Date();
    d->setDHCourante();
    //on met dateTag à la date courante
    this->setDateTag(*d);

    delete d;

    this -> setContenuTag(c);
}

//destructeur
Tag::~Tag()
{}

//assesseurs
void Tag::setContenuTag(const std::string & c)
{    contenuTag = c; }

std::string Tag::getContenuTag() const
{   return contenuTag; }

void Tag::setDateTag(const Date & t)
{    dateTag = t; }

Date Tag::getDateTag() const
{   return dateTag; }


//initialisation à partir d'une chaine de la forme "yyyy-mm-dd contenu"
void Tag::initFromItemTag(std::string s)
{
    std::string date = s.substr(0, 10);
    std::cout<<"Date : "<< date<<std::endl;
    std::string contenu = s.substr(12,s.npos);
    std::cout<<"Contenu : "<<contenu<<std::endl;
    Date d(date);
    setDateTag(d);
    setContenuTag(contenu);
}


//methodes pour l'affichage

std::string Tag::toString() const
{
    std::string s =  "Tag | " + getDateTag().toStringDate() + "\n "+getContenuTag();
    return s;
}

std::string Tag::toItemTxt() //pour l'affichage dans les lists
{
    std::string s = getDateTag().toStringDateAbb() + "\n "+getContenuTag();
    return s;
}

std::ostream& operator<<(std::ostream & os, const Tag & tag)
{
    os << "Tag | " << tag.getDateTag().toStringDate()<< "\n "<<tag.getContenuTag();
    return os;
}

