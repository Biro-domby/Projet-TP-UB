#ifndef FORMULAIRERECHERCHE_H
#define FORMULAIRERECHERCHE_H

#include <contact.h>
#include <date.h>
#include <stdlib.h>

//Pour envoyer les paramètres d'une requête à la BDD

class formulaireRecherche
{
public:
    formulaireRecherche();

    //Assesseurs
    Contact* getContact();
    void setContact(Contact&);
    Date getCrea1();
    Date getCrea2();
    Date getModif1();
    Date getModif2();
    void setCrea1(Date);
    void setCrea2(Date);
    void setModif1(Date);
    void setModif2(Date);

    //Pour rendre nul les dates :
    void setNullCrea1();
    void setNullCrea2();
    void setNullModif1();
    void setNullModif2();


private:
    //Elle comprend un contact et 4 dates
    //Les dates vont par paires : dates de création 1 et 2, dates de modificaiton 1 et 2
    //Crée à la base pour la recherche de contacts mais utilisée pour toutes les recherches

    Contact* contact;
    Date crea1;
    Date crea2;
    Date modif1;
    Date modif2;

    //Si dans une paire :
    //Seule la date1 est remplie -> on recherchera pour la date 1 exacte
    //Les deux dates sont remplies -> on recherchera dans l'intervalle [date1, date2]
    //Seule la date2 est remplie -> on recherchera pour "avant" la date2
};

#endif // FORMULAIRERECHERCHE_H
