#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>
#include <iostream>

//constructeurs
GestionContact::GestionContact()
{
    Date dernSupp;
    std::list<Contact> contactLst;
}

GestionContact::GestionContact(std::list<Contact> liste)
{
    Date dernSupp;
    std::list<Contact> contactLst;
    setContactList(liste);
}


//destructeur
GestionContact::~GestionContact()
{
    contactList.clear();
}

//assesseurs

void GestionContact::setDernSupp(const Date & t)
{    dernSupp = t; }

Date GestionContact::getDernSupp() const
{   return dernSupp; }

void GestionContact::setContactList(std::list<Contact> liste)
{    contactList = liste; }

std::list<Contact> GestionContact::getContactList()
{    return contactList; }


//gestion des contacts
//ajouter un contact
void GestionContact::addContact(const Contact & c)
{    contactList.push_back(c); }

//enlever un contact
void GestionContact::removeContact(const std::string & surname, const std::string & name)
{
    Contact* cont = new Contact(surname, name, "");
    contactList.remove(*cont);
    delete cont;
    Date d;
    d.setDHCourante();
    this->setDernSupp(d);
}

//affichage

QStringList GestionContact::toItemList()//pour l'affichage dans les QListWidget
{
    QStringList l;
    for (auto&& i : contactList){
        QString s;
        s = QString::fromStdString(i.toItemTxt());
        l<<s;
    }
    return l;
}

std::ostream& operator<<(std::ostream & os, const GestionContact & gs)
{
    for (auto&& i : gs.contactList){
        os << i.getNom() << " " << i.getPrenom() << "\n";
    }
    //on affiche la date de dernière modification seulement si elle est différente de la date de création
    // = si il y a eu une modification depuis la création
    if(gs.getDernSupp() != Date())
        os<<"Dernière suppression : "<<gs.getDernSupp().toStringDateH();

    return os;
}

