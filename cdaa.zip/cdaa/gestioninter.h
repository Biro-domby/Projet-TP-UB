#ifndef GESTIONINTER_H
#define GESTIONINTER_H

#include <list>
#include <string>
#include <interaction.h>

class GestionInter
{
private :
    std::list<Interaction> interList;
public:
    //constructeurs
    GestionInter();
    GestionInter(std::list<Interaction>);

    //destructeur
    ~GestionInter();

    //gestion des interactions
    void addInter(Interaction);
    void trier();

    //assesseurs
    std::list<Interaction> getInterList();
    void setInterList(std::list<Interaction>);

    //affichage
    std::string toString() const;
    QStringList toItemList();

    friend std::ostream& operator<<(std::ostream &, const GestionInter &);

};

#endif // GESTIONINTER_H
