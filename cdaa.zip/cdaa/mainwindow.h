#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QGridLayout>
#include <creacontact.h>
#include <creainter.h>
#include <qsqldata.h>
#include <editcontact.h>
#include <QListWidget>
#include <contact.h>
#include <cherchercontact.h>
#include <formulairerecherche.h>
#include <QPixmap>
#include <visuintertodo.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QSQLData interfaceSQL;
    QPixmap im;

    GestionContact * listeContacts;
    Contact * contactSelec;
    Tag * tagSelec;
    formulaireRecherche * rechercheTags;

    creaContact * wContact;
    creaInter * wInter;
    editContact * wEditContact;
    chercherContact * wSearchContact;
    visuInterTodo * wVisuInterTodo;

private slots:

    void contactSelectFromSearch(Contact*);

    void on_ajoutContact_triggered();
    void on_ajoutInter_triggered();

    void on_listWidget_itemClicked(QListWidgetItem *item);

    void majList();
    void razDescr();
    void razList();
    void razListTags();
    void majListTags();
    void majDescr();
    void majAff();
    void razFiltreTags();

    void aucunResultatTag();
    void listeResultatsTag(GestionTag*);

    void listeTodosContactSelect(GestionTag*);

    void on_bModif_clicked();

    void on_bSupprimer_clicked();

    void on_tAlphC_clicked();

    void on_tALphD_clicked();

    void on_chercherContact_triggered();

    void on_bSupprTodo_clicked();

    void on_listTags_itemClicked(QListWidgetItem *item);

    void on_cbDateTag_stateChanged(int arg1);

    void on_cbIntervalTag_stateChanged(int arg1);

    void on_bFiltrer_clicked();

    void on_chercherTagsInter_triggered();

private:
    Ui::MainWindow *ui;
    void remplirLV();

signals:
    void remplirEditContact(Contact&);
    void suppContactSelect(Contact&);
    void remplirListTags(Contact&);
    void suppTagSelect(Tag&);
    void chercherTags(formulaireRecherche&);
    void envoiListeContact(QStringList&);

};

#endif // MAINWINDOW_H
