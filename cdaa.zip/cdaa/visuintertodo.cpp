#include "visuintertodo.h"
#include "ui_visuintertodo.h"
#include "QMessageBox"
#include "stdio.h"
#include "stdlib.h"
#include "iostream"
#include "formulairerecherche.h"
#include "date.h"
#include "contact.h"

//Constructeur
visuInterTodo::visuInterTodo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::visuInterTodo)
{
    ui->setupUi(this);
}

//Destructeur
visuInterTodo::~visuInterTodo()
{
    delete ui;
}


//GESTION DE L'AFFICHAGE

//Appui sur la radioButton Ordre Décroissant
void visuInterTodo::on_rbITriD_clicked()
{    ui->lwInter->sortItems(Qt::DescendingOrder); } //tri décroissant de la liste


//Appui sur la radioButton Ordre Croissant
void visuInterTodo::on_rbITriC_clicked()
{    ui->lwInter->sortItems(Qt::AscendingOrder);  } //tri croissant de la liste


//Appui sur la CheckBox Filter par contact :
void visuInterTodo::on_cbIFiltreContact_stateChanged(int stt)
{
    switch(stt)
    {   case(Qt::Checked): //Nouveau statut : cochée
            //Activation des radioButton Contact et Tous les contactss
            ui->rbIContact->setEnabled(true);
            ui->rbITousContacts->setEnabled(true);
        break;
        case(Qt::Unchecked): //Nouveau statut : décochée
             //Désactivaton + décochage des radio buttons
             ui->rbIContact->setEnabled(false);
             ui->rbITousContacts->setEnabled(false);
             ui->rbIContact->setChecked(false);
             ui->rbITousContacts->setChecked(false);
             //Désactivation de la liste
             ui->comboIContact->setEnabled(false);
        break;
    }
}

//Appui sur le radioButton "Filtrer par contact"
void visuInterTodo::on_rbIContact_clicked()
{    //activation de la comboBox de sélection des contacts
    ui->comboIContact->setEnabled(true);
}

//Appui sur le radioButton "Tous les contacts"
void visuInterTodo::on_rbITousContacts_clicked()
{   //désactivation de la comboBox
    ui->comboIContact->setEnabled(false);
}

//Appui sur la checkBox "Filtrer par date"
void visuInterTodo::on_cbIFiltreDate_stateChanged(int stt)
{
    switch(stt)
    {
        case(Qt::Checked): //Nouvel état : cochée
            //Activation des radioButtons Date d'aujourd'hui, passées et date sélectionnée
            ui->rbIDateToday->setEnabled(true);
            ui->rbIDatePast->setEnabled(true);
            ui->rbIDateSelec->setEnabled(true);
        break;
        case(Qt::Unchecked): //Nouvel état : décochée
            //Désactivation des radioButtons, checkBox et dateEdit des filtres de Dates
            //Décochage  des radioButtons et checkBox
            ui->rbIDateToday->setEnabled(false);
            ui->rbIDatePast->setEnabled(false);
            ui->rbIDateSelec->setEnabled(false);
            ui->cbIDateInterval->setEnabled(false);
            ui->deI1->setEnabled(false);
            ui->deI2->setEnabled(false);
            ui->rbIDateToday->setChecked(false);
            ui->rbIDatePast->setChecked(false);
            ui->rbIDateSelec->setChecked(false);
            ui->cbIDateInterval->setChecked(false);
        break;
    }
}

//Appui sur le radioButton pour une date précise :
void visuInterTodo::on_rbIDateSelec_clicked()
{
    //Activation de la checkBox intervalle de dates
    //Activation de la dateEdit1
    ui->cbIDateInterval->setEnabled(true);
    ui->deI1->setEnabled(true);
}

//Appui sur la checkBox Intervalle de dates
void visuInterTodo::on_cbIDateInterval_stateChanged(int stt)
{
    switch(stt)
    {
        case(Qt::Checked):// nouvel état : cochée
            //Activation de la dateEdit2
            ui->deI2->setEnabled(true);
            break;
        case(Qt::Unchecked)://nouvel état : décochée
            //Désactivation de la dateEdit2
            ui->deI2->setEnabled(false);
            break;
    }
}

//Appui sur la radioButton Date passée
void visuInterTodo::on_rbIDatePast_clicked()
{
    //désactivaton de checkBox Interval de dates et du dEdit1
    ui->cbIDateInterval->setEnabled(false);
    ui->deI1->setEnabled(false);
}

//Appui sur la radioButton Date d'aujourd'hui
void visuInterTodo::on_rbIDateToday_clicked()
{
    //désactivaton de checkBox Interval de dates et du dEdit1
    ui->cbIDateInterval->setEnabled(false);
    ui->deI1->setEnabled(false);
}

//Remplissage de la comboList de contacts
void visuInterTodo::setQstList(QStringList l)
{
    ui->comboIContact->addItems(l);
}


//GESTION DE LA RECHERCHE
//Appui sur le bouton "Recherche"
void visuInterTodo::on_bSearch_clicked()
{
    //On vérifie que rien ne pose problème avec un drapeau :
    bool verif = false;
    //A chaque erreur trouvée, on l'ajoute à la liste :
    QString erreur;

    //si case "Filtrer par Contact" sélectionnée
    if(ui->cbIFiltreContact->isChecked()==true)
    {
        //si la radio "Contact" est cochée
        if(ui->rbIContact->isChecked()==true)
        {
            //mais qu'aucun contact n'est sélectionné dans la liste :
            if(ui->comboIContact->currentIndex()==-1)
            {   //ajout de l'erreur
                erreur.append("Veuillez choisir un contact dans la liste.\n");
                verif = true;
            }
        //sinon, si la radio "Tous les contacts est décochée"
        // = chceckBox Filtre par contact cochée mais aucune option choisie
        }else if(ui->rbITousContacts->isChecked()==false)
        {
            erreur.append("Décochez \"Trier par contact\" ou choississez une des deux options.\n");
            verif = true;
        }
    }
    //si case "Filtrer par date" sélectionnée
    if(ui->cbIFiltreDate->isChecked()==true)
    {
        //mais qu'aucune des trois options n'est sélectionnée:
        if(ui->rbIDateToday->isChecked()==false && ui->rbIDatePast->isChecked()==false && ui->rbIDateSelec->isChecked()==false)
        {
            erreur.append("Décochez \"Trier par date\" ou choisissez une des deux options.\n");
            verif = true;
        }
    }

    //si une erreur a été trouvée:
    if(verif==true)
    {   //on affiche un message :
        QMessageBox msg;
        msg.setText(erreur);
        msg.exec();
    }
    else
    {   //sinon, on remplit la recherche :
        remplirRecherche();
    }
}

//remplissage du formulaire de recherche d'après l'IHM
void visuInterTodo::remplirRecherche()
{
    recherche = new formulaireRecherche();

    //Si la recherche par contact activée
    if(ui->cbIFiltreContact->isChecked() == true && ui->rbIContact->isChecked()== true && ui->comboIContact->currentIndex()!=-1)
    {   //remplissage du contact de la recherche d'après le text de l'item sélectionné
        recherche->getContact()->initFromString(ui->comboIContact->currentText().toStdString());
    }

    //Si la recherche par date est activée
    if(ui->cbIFiltreDate->isChecked()==true)
    {
        //si par Date d'aujourd'hui :
        if(ui->rbIDateToday->isChecked()==true)
        {
            //On remplit les dates Crea1 et 2 :
            recherche->setCrea1(Date().dateCourante());
            recherche->setNullCrea2();
        }
        //si par "Passées" (= avant aujourd'hui)
        else if(ui->rbIDatePast->isChecked()==true)
        {
            recherche->setNullCrea1();
            recherche->setCrea2(Date().dateCourante());
        }
        //si par sélection de dates :
        else if(ui->rbIDateSelec->isChecked()==true)
        {
            //On met Crea1 à la date rentrée dans deI1
            recherche->setCrea1(ui->deI1->date().toString("yyyy-MM-dd").toStdString());
            //Si l'intervalle est activé :
            if(ui->cbIDateInterval->isChecked()==true)
            {
                //on complète la dateEdit2
                recherche->setCrea2(ui->deI2->date().toString("yyyy-MM-dd").toStdString());
            }else{
                //sinon, on la met à null
                recherche->setNullCrea2();
            }
        }
    //si pas de recherche par Date :
    } else {
        //on met les deux dates Crea à null
        recherche->setNullCrea1();
        recherche->setNullCrea2();
    }

    //Si la radioButton Recherche d'intéraction est cochée :
    if(ui->rbModeInter->isChecked()==true)
    {
        //envoie de la recherche d'Intéractions à la BDD
        emit envoiRechercheInter(*recherche);
    //Si la radioButton Recherche de todos est cochée :
    }else if(ui->rbModeTodo->isChecked()==true)
    {
        //envoie de la recherche de Todos à la BDD
        emit envoiRechercheTodo(*recherche);
    }

}

//La BDD indique qu'il n'y a pas de résultat à la recherche de Todos
void visuInterTodo::aucunResultatTodo()
{
    //vidage de la liste
    ui->lwInter->clear();
    //affichage d'un message pour l'utilisateur
    QMessageBox msg;
    msg.setText("Aucun résultat à votre recherche.");
    msg.exec();
}

//La BDD renvoie la liste de résultats de la recherhce de Todos
void visuInterTodo::listeResultatsTodos(GestionTag* l)
{
    //vidage la liste
    ui->lwInter->clear();
    //remplissage avec les résultats
    ui->lwInter->addItems(l->toItemList());
}

//La BDD indique qu'il n'y a pas de résultat à la recherche d'Intéractions
void visuInterTodo::aucunResultatInter()
{
    //vidage de la liste :
    ui->lwInter->clear();
    //affichage d'un message :
    QMessageBox msg;
    msg.setText("Aucun résultat à votre recherche.");
    msg.exec();
}

//La BDD renvoie la liste de résultats de la recherhce d'Intéractions
void visuInterTodo::listeResultatsInter(GestionInter* l)
{
    //vidage de la liste :
    ui->lwInter->clear();
    //remplissage de la liste avec les résultats :
    ui->lwInter->addItems(l->toItemList());
}

