#ifndef CHERCHERCONTACT_H
#define CHERCHERCONTACT_H

#include <QListWidget>
#include <QWidget>
#include <contact.h>
#include <date.h>
#include <formulairerecherche.h>
#include <gestioncontact.h>

namespace Ui {
class chercherContact;
}

class chercherContact : public QWidget
{
    Q_OBJECT

public:
    explicit chercherContact(QWidget *parent = nullptr);
    ~chercherContact();

private slots:
    void on_cbNom_stateChanged(int); //CHECKBOX NOM
    void on_cbPrenom_stateChanged(int); //CHECKBOX PRENOM
    void on_cbEntreprise_stateChanged(int); //CHECKBOX ENTREPRISE
    void on_bChercher_clicked(); //BOUTON CHERCHER
    void on_bAnnuler_clicked(); //BOUTON ANNULER
    void on_liste_itemClicked(QListWidgetItem *); //CLIC SUR UN ITEM DE LA LISTE
    void on_bSelect_clicked(); //BOUTON SELECTIONNER
    void on_cbDateCRea_stateChanged(int); //CHECKBOX DATE CREATION
    void on_cbIntervalCrea_stateChanged(int); //CHECKBOX INTERVAL DATE
    void on_cbDateModif_stateChanged(int); //CHECKBOX DATE MODIFICAITON
    void on_cbInterModif_stateChanged(int); //CHECKBOX INTERVAL MODIFICATION

private:
    Ui::chercherContact *ui;
    Contact* contactSelect; //contact sélectionné dans la liste de résultats
    formulaireRecherche recherche;

    //remplit le formulaire de recherche d'après les élèments remplis par l'utilisateur
    void remplirRecherche();

signals:
    //envoi du formulaire à la BDD
    void envoiRecherche(formulaireRecherche&);
    //fermeture avec le bouton "sélectionner" -> renvoie le contact à mainWindow pour afficher ses infos
    void retourneContactSelec(Contact*);

public slots:
    //quand la BDD indique qu'il n'y a pas de résultats à la requête
    void aucunResultat();
    //quand la BDD renvoie des résultats
    void listeResultats(GestionContact*);
};

#endif // CHERCHERCONTACT_H
