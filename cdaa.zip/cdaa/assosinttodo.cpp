#include "assosinttodo.h"
#include <tag.h>
#include <interaction.h>

//constructeurs
AssosIntTodo::AssosIntTodo()
{
    t = new Tag();
    i = new Interaction();
}

AssosIntTodo::AssosIntTodo(Tag* tag, Interaction* inter)
{
    setTag(tag);
    setInter(inter);
}

//destructeur
AssosIntTodo::~AssosIntTodo()
{
    delete t;
    delete i;
}

//assesseurs
Tag *AssosIntTodo::getTag() const
{    return t; }

void AssosIntTodo::setTag(Tag *tag)
{    t = tag; }

Interaction *AssosIntTodo::getInter() const
{    return i; }

void AssosIntTodo::setInter(Interaction *inter)
{    i = inter; }


