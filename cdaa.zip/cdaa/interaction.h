#ifndef INTERACTION_H
#define INTERACTION_H

#include <ostream>
#include <string>
#include <gestiontag.h>
#include <date.h>

class Interaction
{

private :
    Date date;
    std::string contenu;
    GestionTag tags;

public:

    //constructeur
    Interaction();
    Interaction(const std::string &);
    Interaction(const Date &, const std::string &);

    //destructeur
    ~Interaction();

    //accesseurs
    Date getDate() const;
    std::string getContenu() const;
    GestionTag getTags() const;

    //mutateurs
    void setDate(const Date &);
    void setContenu(const std::string &);
    void setTags(const GestionTag &);

    //méthode pour compléter les attributs dune intéraction à partir d'une liste de tâches sous forme de chaine
    void initFromString(const std::string &);

    //définition des opérateurs de comparaison
    bool operator==(const Interaction &);
    bool operator>(const Interaction & d);
    bool operator>=(const Interaction & d);
    bool operator<(const Interaction & d);
    bool operator<=(const Interaction & d);

    //méthodes pour l'affichage

    std::string toString() const;
    std::string toItemTxt();

    friend std::ostream& operator<<(std::ostream &, const Interaction &);

};

#endif // INTERACTION_H
