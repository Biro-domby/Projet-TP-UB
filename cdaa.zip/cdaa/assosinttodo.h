#ifndef ASSOSINTTODO_H
#define ASSOSINTTODO_H

#include <interaction.h>
#include <tag.h>

class AssosIntTodo
{
private:
    Tag* t;
    Interaction* i;
public:
    //contructeur
    AssosIntTodo();
    AssosIntTodo(Tag*, Interaction*);

    //destructeur
    ~AssosIntTodo();

    //assesseurs
    Tag *getTag() const;
    void setTag(Tag *);
    Interaction *getInter() const;
    void setInter(Interaction *);
};

#endif // ASSOSINTTODO_H
