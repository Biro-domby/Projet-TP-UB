#ifndef EDITCONTACT_H
#define EDITCONTACT_H

#include <QWidget>
#include <contact.h>

namespace Ui {
class editContact;
}

class editContact : public QWidget
{
    Q_OBJECT

public:
    explicit editContact(QWidget *parent = nullptr);
    ~editContact();

    //assesseurs
    void setC(Contact* const);
    Contact* getC() const;
    void setCup(Contact* const);
    Contact* getCup() const;

private slots:

    void on_bAnnuler_clicked();
    void on_bValider_clicked();
    void remplir(Contact&);

private:
    Ui::editContact *ui;
    //Contact sélectionné :
    Contact * c;
    //Contact après modification :
    Contact * cUp;

    void champsObli();
    void updateContact();

signals:
    //envoi à la BDD
    void sigUpdateContact(Contact&, Contact&);

};

#endif // EDITCONTACT_H
