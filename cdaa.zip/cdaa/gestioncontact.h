#ifndef GESTIONCONTACT_H
#define GESTIONCONTACT_H

#include <contact.h>
#include <list>
#include <ctime>

class GestionContact
{
private :
    std::list<Contact> contactList;
    Date dernSupp;

public:
    //constructeurs
    GestionContact();
    GestionContact(std::list<Contact>);

    //destructeur
    ~GestionContact();

    //gestion des contacts
    void addContact(const Contact &);
    void removeContact(const std::string &, const std::string &); //par nom et prénom

    //assesseurs
    std::list<Contact> getContactList();
    void setContactList(std::list<Contact>);
    Date getDernSupp() const;
    void setDernSupp(const Date &);

    //affichage
    friend std::ostream& operator<<(std::ostream &,const GestionContact &);
    QStringList toItemList();

};


#endif // GESTIONCONTACT_H
