#include "cherchercontact.h"
#include "ui_cherchercontact.h"
#include "QMessageBox"
#include "contact.h"
#include "date.h"
#include "stdio.h"
#include "iostream"
#include "qdebug.h"
#include "formulairerecherche.h"

chercherContact::chercherContact(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chercherContact)
{
    ui->setupUi(this);
}

chercherContact::~chercherContact()
{
    delete ui;
}

//Appui sur la case "Nom"
void chercherContact::on_cbNom_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : coché
        ui->leNom->setEnabled(true); //Active la lineEdit Nom
        break;
    case Qt::Unchecked: //Nouvel état : décoché
        ui->leNom->setEnabled(false); //Désactive la lineEdit Nom
        break;
    }
}

//Appui sur la case "Prénom"
void chercherContact::on_cbPrenom_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : coché
        ui->lePrenom->setEnabled(true); //Active la lineEdit Prenom
        break;
    case Qt::Unchecked: //Nouvel état : décoché
        ui->lePrenom->setEnabled(false); //Désactive la lineEdit Nom
        break;
    }
}

//Appui sur la case "Entreprise"
void chercherContact::on_cbEntreprise_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : coché
        ui->leEntreprise->setEnabled(true); //Active la lineEdit Entreprise
        break;
    case Qt::Unchecked: //Nouvel état : décoché
        ui->leEntreprise->setEnabled(false); //Désactive la lineEdit Entreprise
        break;
    }
}

//A l'appui sur le bouton "Rechercher"
void chercherContact::on_bChercher_clicked()
{
    //Désactivation du bouton "Sélectionner"
    ui->bSelect->setEnabled(false);

    //Si aucune checkBox n'est cochée :
    if(ui->cbNom->isChecked()==false && ui->cbPrenom->isChecked()==false && ui->cbEntreprise->isChecked()==false && ui->cbDateCRea->isChecked()==false && ui->cbDateModif->isChecked()==false)
    {
        //erreur :
        QMessageBox msgBox;
        msgBox.setText("Veuillez sélectionner au moins un critère de recherche.");
        msgBox.exec();
    }
    //Si une des checkBox est cochée mais que le champ n'est pas rempli :
    else if((ui->cbNom->isChecked()==true && ui->leNom->text().isEmpty()==true) || (ui->cbPrenom->isChecked()==true && ui->lePrenom->text().isEmpty()==true ) || (ui->cbEntreprise->isChecked()==true && ui->leEntreprise->text().isEmpty()==true ))
    {
        //erreur :
        QMessageBox msgBox;
        msgBox.setText("Veuillez remplir le⸱s champ⸱s sélectionné⸱s");
        msgBox.exec();
    //Sinon, tout est ok :
    } else {
        //on remplit le formulaire de recherche
        remplirRecherche();
    }
}

//remplissage du formulaire de recherche :
void chercherContact::remplirRecherche()
{
    Contact *c = new Contact();

    //Si la checkBox Nom est cochée :
    if(ui->cbNom->isChecked()==true)
        //on remplit le nom :
        c->setNom(ui->leNom->text().toStdString());
    else
        c->setNom("");

    //Si la checkbox Prenom est cochée :
    if(ui->cbPrenom->isChecked()==true)
        //on remplir le prénom :
        c->setPrenom(ui->lePrenom->text().toStdString());
    else
        c->setPrenom("");

    //SI la checkbox Entreprise est cochée :
    if(ui->cbEntreprise->isChecked()==true)
        //on remplir l'enteprise :
        c->setEntreprise(ui->leEntreprise->text().toStdString());
    else
        c->setEntreprise("");

    //Si la checkbox Date de création est décochée :
    if(ui->cbDateCRea->isChecked()==false)
    {
        //les deux dates de Creation sont à NULL
        recherche.setNullCrea1();
        recherche.setNullCrea2();
    }

    //Si la checkbox Dete de création est cochée, mais pas l'intervalle :
    if(ui->cbDateCRea->isChecked()==true && ui->cbIntervalCrea->isChecked()==false)
    {
        //On remplit la date Crea1 à celle du champ correspondant
        recherche.setCrea1(ui->deCrea1->date().toString("yyyy-MM-dd").toStdString());
        recherche.setNullCrea2();
    }

    //Si les checkbox Date de création et Intervalle sont cochées :
    if(ui->cbDateCRea->isChecked()==true && ui->cbIntervalCrea->isChecked()==true)
    {
        //On remplit les dates Crea1 et Crea2 aux dates correspondantes
        recherche.setCrea1(ui->deCrea1->date().toString("yyyy-MM-dd").toStdString());
        recherche.setCrea2(ui->deCrea2->date().toString("yyyy-MM-dd").toStdString());
    }

    //idem pour les dates de modifications
    if(ui->cbDateModif->isChecked()==false)
    {
        recherche.setNullModif1();
        recherche.setNullModif2();
    }

    if(ui->cbDateModif->isChecked()==true && ui->cbInterModif->isChecked()==false)
    {
        recherche.setModif1(ui->deModif1->date().toString("yyyy-MM-dd").toStdString());
        recherche.setNullModif2();
    }

    if(ui->cbDateModif->isChecked()==true && ui->cbInterModif->isChecked()==true)
    {
        recherche.setModif1(ui->deModif1->date().toString("yyyy-MM-dd").toStdString());
        recherche.setModif2(ui->deModif2->date().toString("yyyy-MM-dd").toStdString());
    }

    //On attribut le contact remplit (ou non) au formulaire de recherche
    recherche.setContact(*c);

    //envoie de la recherche à la BDD
    emit envoiRecherche(recherche);
}

//La BDD indique qu'il n'y a pas de résultat :
void chercherContact::aucunResultat()
{
    //on vide la liste
    ui->liste->clear();
    //indication à l'utilisateur
    QMessageBox msgBox;
    msgBox.setText("Il n'y aucun résultat pour cette recherche.");
    msgBox.exec();
}

//La BDD renvoie une liste de résultats :
void chercherContact::listeResultats(GestionContact* gc)
{
    //on vide la liste :
    ui->liste->clear();
    //on la remplit :
    ui->liste->addItems(gc->toItemList());
}

//Appui sur le bouton annuler  = fermeture
void chercherContact::on_bAnnuler_clicked()
{    close(); }


//Appui sur un contact de la liste :
void chercherContact::on_liste_itemClicked(QListWidgetItem *)
{
    //Activation du bouton "Sélectionner"
    ui->bSelect->setEnabled(true);
}

//Appui sur le bouton sélectionner :
void chercherContact::on_bSelect_clicked()
{
    //On crée un contact d'après le texte de l'item sélectionné dans la liste
    Contact*c = new Contact();
    c->initFromString(ui->liste->selectedItems()[0]->text().toStdString());
    //SIGNAL vers le MainWindow : on lui envoie ce contact
    emit retourneContactSelec(c);
    //fermeture
    close();
}


//Au clic sur la checkBox créa
void chercherContact::on_cbDateCRea_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //si nouvel état : cochée
        //Activation de la dateEdit Crea1 et de la checkBox IntervalCrea
        ui->deCrea1->setEnabled(true);
        ui->cbIntervalCrea->setEnabled(true);
        break;
    case Qt::Unchecked: //si nouvel état : décochée
        //Désactivation
        ui->deCrea1->setEnabled(false);
        ui->cbIntervalCrea->setEnabled(false);
        ui->cbIntervalCrea->setChecked(false);
        ui->deCrea2->setEnabled(false);
        break;
    }
}

//AU clic sur la checkbox IntervalCrea
void chercherContact::on_cbIntervalCrea_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : cochée
        //Activation de la dateEdit Crea2
        ui->deCrea2->setEnabled(true);
        break;
    case Qt::Unchecked: //Nouvel état : décochée
        //Désactivation
        ui->deCrea2->setEnabled(false);
        break;
    }
}


//Au clic sur la checkBox DateModif
void chercherContact::on_cbDateModif_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : cochée
        //Activation de la dateEdit Modif1 et de la checkBox Modif
        ui->deModif1->setEnabled(true);
        ui->cbInterModif->setEnabled(true);
        break;
    case Qt::Unchecked: //Nouvel état : décochée
        //Désactivation
        ui->deModif1->setEnabled(false);
        ui->cbInterModif->setEnabled(false);
        ui->cbInterModif->setChecked(false);
        ui->deModif2->setEnabled(false);
        break;
    }
}

//Au clic sur la checkBox InterModif
void chercherContact::on_cbInterModif_stateChanged(int stt)
{
    switch (stt) {
    case Qt::Checked: //Nouvel état : cochée
        //Activation de la dateEdit Modif2
        ui->deModif2->setEnabled(true);
        break;
    case Qt::Unchecked: //Nouvel état : décochée
        //Désactivation
        ui->deModif2->setEnabled(false);
        break;
    }
}

