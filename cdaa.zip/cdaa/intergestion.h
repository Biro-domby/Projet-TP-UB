#ifndef INTERGESTION_H
#define INTERGESTION_H


class InterGestion
{
public:
    InterGestion();
};

#endif // INTERGESTION_H
