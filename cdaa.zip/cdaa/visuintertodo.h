#ifndef VISUINTERTODO_H
#define VISUINTERTODO_H

#include <QWidget>
#include <formulairerecherche.h>
#include <contact.h>
#include <date.h>
#include <gestiontag.h>
#include <tag.h>
#include <gestioninter.h>
#include <interaction.h>


namespace Ui {
class visuInterTodo;
}

class visuInterTodo : public QWidget
{
    Q_OBJECT

public:
    explicit visuInterTodo(QWidget *parent = nullptr);
    ~visuInterTodo();
    //remplissage de la liste de résultats :
    void setQstList(QStringList);

private slots:
    //filtre par contact
    void on_cbIFiltreContact_stateChanged(int); //CHECKBOX FILTRE CONTACT
    void on_rbIContact_clicked(); //RADIOBUTTON CONTACT
    void on_rbITousContacts_clicked(); //RADIOBUTTON TOUS LES CONTACTS
    //filtre par date :
    void on_cbIFiltreDate_stateChanged(int); //CHECKBOX FILTRE DATE
    void on_rbIDateSelec_clicked(); //RADIOBUTTON DATE EXACTE
    void on_cbIDateInterval_stateChanged(int); //CHECKBOX INTERVALLE DE DATES
    void on_rbIDatePast_clicked(); //RADIOBUTTON DATES PASSEES
    void on_rbIDateToday_clicked(); //RADIOBUTTON DATE D'AUJOURD'HUI
    //autres
    void on_bSearch_clicked();//BOUTON CHERCHER
    void on_rbITriD_clicked();//RADIOBUTTON TRI DECROISSSANT
    void on_rbITriC_clicked();//RADIOBUTTON TRI CROISSANT

private:
    Ui::visuInterTodo *ui;

    formulaireRecherche * recherche;
    void remplirRecherche();

signals:
    //Envoi d'une recherche d'intéractions à la BDD
    void envoiRechercheInter(formulaireRecherche&);
    //Envoi d'une recherche de tags à la BDD
    void envoiRechercheTodo(formulaireRecherche&);


public slots:
    //La BDD ne renvoie pas de résultat à la recherche de Todos
    void aucunResultatTodo();
    //La BDD renvoie une liste de recherche de Todos
    void listeResultatsTodos(GestionTag*);

    //La BDD ne renvoie pas de résultat à la recherche d'intéractions
    void aucunResultatInter();
    //La BDD renvoie une liste de recherche dintéractions
    void listeResultatsInter(GestionInter*);
};

#endif // VISUINTERTODO_H
