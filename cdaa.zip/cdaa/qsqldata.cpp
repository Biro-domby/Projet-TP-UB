#include "qsqldata.h"
#include <QDebug>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include <contact.h>
#include <interaction.h>
#include <tag.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <gestioncontact.h>
#include <formulairerecherche.h>
#include <date.h>
#include <gestiontag.h>
#include <gestioninter.h>


//Initialisation et connection de la BDD

QSQLData::QSQLData(QObject *parent) : QObject(parent)
{
    dbOuverte = false;
    connectDB("inutile");
}

QSQLData::~QSQLData()
{
    closeDB();
}

void QSQLData::isOpen(bool & b)
{    isDBOpen(b); }

void QSQLData::isDBOpen(bool & b)
{    b = dbOuverte; }

void QSQLData::closeDB()
{
    if(dbOuverte== true)
        db.close();
}

bool QSQLData::connectDB(const QString &)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    QString localeUri = "/home/artheme/Bureau/CDAA/Projet/build-projetcdaa-Desktop-Debug/base.sqlite";

    db.setDatabaseName( localeUri );

    if(!db.open())
    {
        qDebug() << "Pas de connexion à la BDD" ;
        dbOuverte = false;
    }
    else
    {
        qDebug() << "Connexion réussie à la BDD";
        dbOuverte = true;
    }
    return dbOuverte;
}


//SLOTS
//Création de contact
void QSQLData::bddCreateContact(Contact & c)
{   createContact(c); }

//Suppression de contact
void QSQLData::bddDeleteContact(Contact & c)
{    deleteContact(c); }

//MIse à jour d'un contact
void QSQLData::bddUpdateContact(Contact & c, Contact & q)
{   updateContact(c, q); }

//Recherche d'un contact
void QSQLData::bddRechercheContacts(formulaireRecherche & f)
{    searchContact(f); }

//Création d'une intéraction
void QSQLData::bddCreateInter(Interaction & i, Contact & c)
{   createInter(i,c); }

//Recherche d'une intéraction
void QSQLData::bddRechercheInter(formulaireRecherche & f)
{   searchInter(f);  }

//Suppression d'un tag
void QSQLData::bddDeleteTag(Tag & t)
{    deleteTag(t);  }

//Recherche d'un tag depuis la mainWindow
void QSQLData::bddRechercheTags(formulaireRecherche & t)
{    searchTag(t); }

//Recherche d'un tag depuis la fentre de recherche
void QSQLData::bddRechercheTodos(formulaireRecherche & f)
{    searchTodos(f);  }

//Recherche des tags d'un contact
void QSQLData::bddGetTags(Contact & c)
{     getTags(c); }


//METHODES / REQUETES

//Retourne la liste des Contacts (pour les affichages dans des listes ou comboBox)
GestionContact* QSQLData::getStdListContacts()
{
    GestionContact* gc = new GestionContact();
    if(dbOuverte == true)
    {
        //On récupère tous les attributs d'un contact
        QSqlQuery query("SELECT idContact, tel, mail, photo, dateCreation, dateModif, nom, prenom, entreprise FROM Contacts");
        if(!query.exec())
        {
            qDebug() << "Impossible d'exécuter la requête";
        }else{

            qDebug() << "Requête exécutée";

            while(query.next())
            {   //On créé un contact et on remplit ses attributs d'après les valeurs extraites de la BDD
                Contact c;
                //Nom
                c.setNom(query.value(6).toString().toStdString());
                //Prenom
                c.setPrenom(query.value(7).toString().toStdString());
                //Entreprise
                c.setEntreprise(query.value(8).toString().toStdString());
                //Date de création
                Date d1(query.value(4).toString().toStdString());
                c.setDate(d1);
                //Date de dernière modification
                Date d2(query.value(5).toString().toStdString());
                c.setDernModif(d2);

                //Numéro de téléphone
                if (!query.value(1).isNull())
                    c.setTelephoneFromStd(query.value(1).toString().toStdString());

                //Mail
                if (!query.value(2).isNull())
                    c.setMail(query.value(2).toString().toStdString());
                else
                    c.setMail("");

                //Uri de la photo
                if (!query.value(3).isNull())
                    c.setUriPhoto(query.value(3).toString().toStdString());
                else
                    c.setUriPhoto("");

                //On l'ajoute à la liste
                gc->addContact(c);
            }
        }
    }
    //On retourne la liste
    return gc;
}

//Retourne un contact d'après les infos extraites du texte d'un item de liste ou comboBox
Contact *QSQLData::getContact(std::string contactSt)
{
    Contact* c = new Contact();

    //remplissage du contact d'après contactST
    std::size_t found = contactSt.find(" ");
    c->setNom(contactSt.substr(0,found));
    contactSt = contactSt.substr(found+1);
    found = contactSt.find(", ");
    c->setPrenom(contactSt.substr(0,found));
    contactSt = contactSt.substr(found+2);
    c->setEntreprise(contactSt);

    if(dbOuverte == true)
    {
        QSqlQuery query;
        query.prepare("SELECT idContact, tel, mail, photo, dateCreation, dateModif FROM Contacts WHERE nom=? AND prenom=? AND entreprise=?");
        query.addBindValue(QString::fromStdString(c->getNom()));
        query.addBindValue(QString::fromStdString(c->getPrenom()));
        query.addBindValue(QString::fromStdString(c->getEntreprise()));

        if(!query.exec())
        {
            qDebug() << "Impossible d'exécuter la requête";

        }else{

            if (query.next())
            {
                //On remplit le reste des informations grace aux valeurs de la BDD :
                //date de création
                Date d1(query.value(4).toString().toStdString());
                c->setDate(d1);
                //date de dernière modification
                Date d2(query.value(5).toString().toStdString());
                c->setDernModif(d2);

                //téléphone :
                if (!query.value(1).isNull())
                    c->setTelephoneFromStd(query.value(1).toString().toStdString());

                //mail :
                if (!query.value(2).isNull())
                    c->setMail(query.value(2).toString().toStdString());
                else
                    c->setMail("");

                //uri de la Photo
                if (!query.value(3).isNull())
                    c->setUriPhoto(query.value(3).toString().toStdString());
                else
                    c->setUriPhoto("");
            }
            qDebug() << "Requête exécutée: contact trouvé\n";

        }
    }
    //on retourne ce contact
    return c;
}

//insertion d'un contact dans la BDD
bool QSQLData::createContact(const Contact & c) const
{
    if(dbOuverte == true)
    {
        QSqlQuery query;

        query.prepare("INSERT INTO Contacts (nom, prenom, entreprise, dateCreation, dateModif) VALUES (:n, :p, :e, :d, :m)");

        //remplissage des valeurs d'après les attributs du contact
        query.bindValue(":n", QString::fromStdString(c.getNom()));
        query.bindValue(":p", QString::fromStdString(c.getPrenom()));
        query.bindValue(":e", QString::fromStdString(c.getEntreprise()));
        query.bindValue(":d", QString::fromStdString(c.getDate().toStringDateAbb()));
        query.bindValue(":m", QString::fromStdString(c.getDernModif().toStringDateAbb()));

        if(!query.exec())
        {
            qDebug() << "Erreur à la création";
            return false;
        }
    }
    return true;
}

//suppression d'un contact :
bool QSQLData::deleteContact(const Contact & p) const
{
    if(dbOuverte == true)
    {
        QSqlQuery query;

        query.prepare("DELETE FROM Contacts WHERE nom=:n AND prenom = :p AND entreprise=:e;");

        //remplissages des valeurs d'après les attributs du contact
        query.bindValue(":n", QString::fromStdString(p.getNom()));
        query.bindValue(":p", QString::fromStdString(p.getPrenom()));
        query.bindValue(":e", QString::fromStdString(p.getEntreprise()));

        if(!query.exec())
        {
            qDebug() << "Erreur à la suppression";
            return false;
        }else{
            qDebug() << "Contact supprimé";
        }
    }
    return true;
}

//modification du contact p, remplacé par q
bool QSQLData::updateContact(const Contact & p, const Contact & q) const
{
    if(dbOuverte == true)
    {
        QSqlQuery query;

        query.prepare("UPDATE Contacts SET nom=?, prenom=?, entreprise=?, dateModif=? WHERE nom=? and prenom=? and entreprise=?");

        //remplissage des champs d'après les attributs de q et p
        query.addBindValue(QString::fromStdString(q.getNom()));
        query.addBindValue(QString::fromStdString(q.getPrenom()));
        query.addBindValue(QString::fromStdString(q.getEntreprise()));
        query.addBindValue(QString::fromStdString(q.getDate().toStringDateAbb()));
        query.addBindValue(QString::fromStdString(p.getNom()));
        query.addBindValue(QString::fromStdString(p.getPrenom()));
        query.addBindValue(QString::fromStdString(p.getEntreprise()));

        if(!query.exec())
        {
            qDebug() << "Erreur à la mise à jour";
            return false;
        }else{
            qDebug() << "Contact mis à jour";

            //une fois que les attribut principaux sont remplis, on remplit les autres si besoin
            //mail
            if(q.getMail()!=p.getMail())
            {
                query.prepare("UPDATE Contacts SET mail=? WHERE nom=? and prenom=? and entreprise=?");

                query.addBindValue(QString::fromStdString(q.getMail()));

                query.addBindValue(QString::fromStdString(p.getNom()));
                query.addBindValue(QString::fromStdString(p.getPrenom()));
                query.addBindValue(QString::fromStdString(p.getEntreprise()));

                query.exec();
            }

            //telephone
            if(q.getStTelephone()!=p.getStTelephone())
            {
                query.prepare("UPDATE Contacts SET tel=? WHERE nom=? and prenom=? and entreprise=?");

                query.addBindValue(QString::fromStdString(q.getStTelephone()));

                query.addBindValue(QString::fromStdString(p.getNom()));
                query.addBindValue(QString::fromStdString(p.getPrenom()));
                query.addBindValue(QString::fromStdString(p.getEntreprise()));

                query.exec();
            }

            //photo
            if(q.getUriPhoto()!=p.getUriPhoto())
            {
                query.prepare("UPDATE Contacts SET photo=? WHERE nom=? and prenom=? and entreprise=?");

                query.addBindValue(QString::fromStdString(q.getUriPhoto()));

                query.addBindValue(QString::fromStdString(p.getNom()));
                query.addBindValue(QString::fromStdString(p.getPrenom()));
                query.addBindValue(QString::fromStdString(p.getEntreprise()));

                query.exec();
            }


        }

    }
    emit finMajBDD();
    //demande à mainWindow de remettre à jour la liste de contacts
    return true;
}

//recherche d'un contact, d'après le formulaire
bool QSQLData::searchContact(formulaireRecherche & f) const
{
    QStringList l;

    if(dbOuverte == true)
    {
        QSqlQuery query;

        //requête de base :
        QString s = "SELECT nom, prenom, entreprise FROM Contacts WHERE";

        //on ajoute éventuellement des filtres suivant le remplissage du formulaire :
        //nom
        if(f.getContact()->getNom()!="")
            s+=" nom=:n and";
        //prenom
        if(f.getContact()->getPrenom()!="")
            s+=" prenom=:p and";
        //entreprise
        if(f.getContact()->getEntreprise()!="")
            s+=" entreprise=:e and";

        //date de création
        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            s+=" dateCreation=:d and";

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
            s+=" dateCreation>=:di and dateCreation<=:ds and";

        //date de modification
        if(f.getModif1().isNull()==false && f.getModif2().isNull()==true)
            s+=" dateModif=:m and";

        if(f.getModif1().isNull()==false && f.getModif2().isNull()==false)
            s+=" dateModif>=:mi and dateModif<=:ms and";

        //on enlève le "an" qui se trouve éventuellement à la fin
        if(s.endsWith(" and"))
            s.chop(4);


        query.prepare(s);

        //De même, on ajoute les valeurs
        //nom
        if(f.getContact()->getNom()!="")
            query.bindValue(":n", QString::fromStdString(f.getContact()->getNom()));
        //prenom
        if(f.getContact()->getPrenom()!="")
            query.bindValue(":p", QString::fromStdString(f.getContact()->getPrenom()));
        //entreprise
        if(f.getContact()->getEntreprise()!="")
            query.bindValue(":e", QString::fromStdString(f.getContact()->getEntreprise()));

        //date de création
        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            query.bindValue(":d", QString::fromStdString(f.getCrea1().toStringDateAbb()));

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
        {
            query.bindValue(":di", QString::fromStdString(f.getCrea1().toStringDateAbb()));
            query.bindValue(":ds", QString::fromStdString(f.getCrea2().toStringDateAbb()));
        }

        //date de modification
        if(f.getModif1().isNull()==false && f.getModif2().isNull()==true)
            query.bindValue(":m", QString::fromStdString(f.getModif1().toStringDateAbb()));

        if(f.getModif1().isNull()==false && f.getModif2().isNull()==false)
        {
            query.bindValue(":mi", QString::fromStdString(f.getModif1().toStringDateAbb()));
            query.bindValue(":ms", QString::fromStdString(f.getModif2().toStringDateAbb()));
        }

        if(!query.exec())
        {
            qDebug() << "Erreur à la recherche";
            return false;
        }else{
            qDebug() << "Recherche effectuée";

            if(query.next())
            {
                query.previous();
                GestionContact* gc = new GestionContact();

                //si on a des résultats, on crée un GestionContact dont la liste de contacts
                //contiendra tous les résultats
                while(query.next())
                {
                    Contact *c = new Contact();
                    c->setNom(query.value(0).toString().toStdString());
                    c->setPrenom(query.value(1).toString().toStdString());
                    c->setEntreprise(query.value(2).toString().toStdString());
                    gc->addContact(*c);
                }
                //on renvoie les résultats
                emit envoieResultatsRechercheContacts(gc);
            }
            else{
                //sinon, on indique qu'il n'y a pas de résultats
                emit pasDeResulRechercheContacts();
            }

        }
    }
    return true;
}

//recherche de tags depuis la mainWindow
bool QSQLData::searchTag(formulaireRecherche & f) const
{
    QStringList l;

    if(dbOuverte == true)
    {
        QSqlQuery query;

        QString s = "SELECT dateTag, contenuTag FROM Tags, AssociationTI, Interactions, Contacts WHERE nom=:n and prenom=:p and entreprise=:e and Contacts.idContact = Interactions.idContact and Interactions.idInteraction = AssociationTI.idInter and AssociationTI.idTag = Tags.idTag and";

        //si il n'y a pas d'intervalle de date
        if(f.getCrea2().isNull()==true)
            s+=" dateTag=:d;";

        //s'il y a un intervalle
        if(f.getCrea2().isNull()==false)
            s+=" dateTag>=:di and dateTag<=:ds;";

        //correction de la requête
        if(s.endsWith(" and"))
            s.chop(4);

        query.prepare(s);

        //ajout des valeurs
        query.bindValue(":n", QString::fromStdString(f.getContact()->getNom()));
        query.bindValue(":p", QString::fromStdString(f.getContact()->getPrenom()));
        query.bindValue(":e", QString::fromStdString(f.getContact()->getEntreprise()));

        if(f.getCrea2().isNull()==true)
            query.bindValue(":d", QString::fromStdString(f.getCrea1().toStringDateAbb()));

        if(f.getCrea2().isNull()==false)
        {
            query.bindValue(":di", QString::fromStdString(f.getCrea1().toStringDateAbb()));
            query.bindValue(":ds", QString::fromStdString(f.getCrea2().toStringDateAbb()));
        }


        if(!query.exec())
        {
            qDebug() << "Erreur à la recherche de Tags";
            return false;
        }else{
            qDebug() << "Recherche effectuée";

            if(query.next())
            {
                //s'il y a des résultats :
                query.previous();
                GestionTag * gt = new GestionTag();

                //on les ajoute à la liste d'un gestionTag
                while(query.next())
                {
                    Tag* t = new Tag();
                    t->setDateTag(query.value(0).toString().toStdString());
                    t->setContenuTag(query.value(1).toString().toStdString());
                    gt->addTag(*t);

                }
                //on renvoie les résultats
                emit envoieResultatsTags(gt);
            }
            else{
                //sinon, on indique qu'il n'y a pas de résultats
                emit pasDeResulRechercheTags();
            }

        }
    }
    return true;
}

//recherche de todos (depuis une fenêtre visuInterTodo
bool QSQLData::searchTodos(formulaireRecherche & f) const
{
    //le fonctionnement est le même que pour searchTags
    QStringList l;

    if(dbOuverte == true)
    {

        QSqlQuery query;
        QString s = "SELECT dateTag, contenuTag, nom, prenom FROM Tags, Interactions, Contacts, AssociationTI WHERE Contacts.idContact = Interactions.idContact and Interactions.idInteraction = AssociationTI.idInter and AssociationTI.idTag = Tags.idTag and";


        if(f.getContact()->getNom()!="" && f.getContact()->getPrenom()!="" && f.getContact()->getEntreprise()!="")
            s+=" nom=:n and prenom=:p and entreprise=:e and";


        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            s+=" dateTag=:d;";

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
            s+=" dateTag>=:di and dateTag<=:ds;";

        if(f.getCrea1().isNull()==true && f.getCrea2().isNull()==false)
            s+=" dateTag<:d;";


        if(s.endsWith(" and"))
            s.chop(4);


        query.prepare(s);


        if(f.getContact()->getNom()!="" && f.getContact()->getPrenom()!="" && f.getContact()->getEntreprise()!="")
        {
            query.bindValue(":n", QString::fromStdString(f.getContact()->getNom()));
            query.bindValue(":p", QString::fromStdString(f.getContact()->getPrenom()));
            query.bindValue(":e", QString::fromStdString(f.getContact()->getEntreprise()));
        }


        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            query.bindValue(":d", QString::fromStdString(f.getCrea1().toStringDateAbb()));

        if(f.getCrea1().isNull()==true && f.getCrea2().isNull()==false)
             query.bindValue(":d", QString::fromStdString(f.getCrea2().toStringDateAbb()));

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
        {
            query.bindValue(":di", QString::fromStdString(f.getCrea1().toStringDateAbb()));
            query.bindValue(":ds", QString::fromStdString(f.getCrea2().toStringDateAbb()));
        }


        if(!query.exec())
        {
            qDebug() << "Erreur à la recherche de Todos";
            return false;
        }else{
            qDebug() << "Recherche effectuée";

            if(query.next())
            {
                query.previous();

                GestionTag *gt = new GestionTag();

                while(query.next())
                {
                    Tag* t = new Tag();
                    t->setDateTag(query.value(0).toString().toStdString());
                    t->setContenuTag(query.value(2).toString().toStdString() + " " + query.value(3).toString().toStdString() + "\n" + query.value(1).toString().toStdString());       
                    gt->addTag(*t);
                }
                emit envoieResultatsTodos(gt);
            }
            else{
                emit pasDeResulRechercheTodos();
            }

        }
    }
    return true;
}


//Recherche d'intéractions depuis une fenêtre visuInterTodo
bool QSQLData::searchInter(formulaireRecherche &f) const
{
    //le fonctionnement est similaire à searchTags
    QStringList l;

    if(dbOuverte == true)
    {
        QSqlQuery query;

        QString s = "SELECT dateInteraction, contenu, nom, prenom FROM Interactions, Contacts WHERE Contacts.idContact = Interactions.idContact and";

        if(f.getContact()->getNom()!="" && f.getContact()->getPrenom()!="" && f.getContact()->getEntreprise()!="")
            s+=" nom=:n and prenom=:p and entreprise=:e and";

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            s+=" dateInteraction=:d;";

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
            s+=" dateInteraction>=:di and dateInteraction<=:ds;";

        if(f.getCrea1().isNull()==true && f.getCrea2().isNull()==false)
            s+=" dateInteraction<:d;";


        if(s.endsWith(" and"))
            s.chop(4);

        query.prepare(s);


        if(f.getContact()->getNom()!="" && f.getContact()->getPrenom()!="" && f.getContact()->getEntreprise()!="")
        {
            query.bindValue(":n", QString::fromStdString(f.getContact()->getNom()));
            query.bindValue(":p", QString::fromStdString(f.getContact()->getPrenom()));
            query.bindValue(":e", QString::fromStdString(f.getContact()->getEntreprise()));
        }

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==true)
            query.bindValue(":d", QString::fromStdString(f.getCrea1().toStringDateAbb()));

        if(f.getCrea1().isNull()==true && f.getCrea2().isNull()==false)
             query.bindValue(":d", QString::fromStdString(f.getCrea2().toStringDateAbb()));

        if(f.getCrea1().isNull()==false && f.getCrea2().isNull()==false)
        {
            query.bindValue(":di", QString::fromStdString(f.getCrea1().toStringDateAbb()));
            query.bindValue(":ds", QString::fromStdString(f.getCrea2().toStringDateAbb()));
        }

        if(!query.exec())
        {
            qDebug() << "Erreur à la recherche d'Intéractions";
            return false;
        }else{
            qDebug() << "Recherche effectuée";

            if(query.next())
            {
                query.previous();

                GestionInter* gi = new GestionInter();

                while(query.next())
                {
                    Interaction* i = new Interaction();
                    i->setDate(query.value(0).toString().toStdString());
                    std::string s = query.value(2).toString().toStdString()+ " " + query.value(3).toString().toStdString();
                    s += "\n" + query.value(1).toString().toStdString();
                    i->setContenu(s);
                    gi->addInter(*i);
                }
                emit envoieResultatsInter(gi);
            }
            else{
                emit pasDeResulRechercheInter();
            }

        }
    }
    return true;
}

//insertion d'une intéraction
bool QSQLData::createInter(const Interaction & i, const Contact & c) const
{
    if(dbOuverte == true)
    {
        //on récupère d'abord l'id du contact associé à l'intéraction
        QSqlQuery query;
        query.prepare("SELECT idContact FROM Contacts WHERE nom=? AND prenom=? AND entreprise=?");
        query.addBindValue(QString::fromStdString(c.getNom()));
        query.addBindValue(QString::fromStdString(c.getPrenom()));
        query.addBindValue(QString::fromStdString(c.getEntreprise()));

        if(!query.exec())
        {
            qDebug() << "Impossible d'exécuter la requête";
            return false;
        }else{

            qDebug() << "Requête exécutée";
            if(query.next())
            {
                int idC = query.value(0).toInt();

                QSqlQuery queryInter;

                //on insère ensuite cette intéraction
                queryInter.prepare("INSERT INTO Interactions (idContact, dateInteraction, contenu) VALUES (:c, :d, :t)");

                queryInter.bindValue(":c", idC);
                queryInter.bindValue(":d", QString::fromStdString(i.getDate().toStringDateAbb()));
                queryInter.bindValue(":t", QString::fromStdString(i.getContenu()));

                if(!queryInter.exec())
                {
                    qDebug() << "Erreur à l'insertion de l'intéraction";
                    return false;
                }else{
                    qDebug() << "Intéraction insérée dans la base de donnée";
                    //s'il y a des tags associés
                    if(i.getTags().getTagList().size()!=0)
                        //on les insert
                        createTag(i);
                    else
                         qDebug() << "Aucun Tag à insérer";
                }
            }
            else
            {
                qDebug()<< "Aucune ligne correspondante";
            }
        }
    }
    return true;
}

//Insertion des tags d'une intéraction
bool QSQLData::createTag(const Interaction & i) const
{
    if(dbOuverte == true){

        //pour chaque tag de la listeTag de l'intéraction :
        for (auto&& t : i.getTags().getTagList()){
            //on l'insert dans la base de donnnée
            QSqlQuery query;
            query.prepare("INSERT INTO Tags (dateTag, contenuTag) VALUES (:d, :c)");
            query.bindValue(":d", QString::fromStdString(t.getDateTag().toStringDateAbb()));
            query.bindValue(":c", QString::fromStdString(t.getContenuTag()));

            if(!query.exec())
            {
                qDebug() << "Erreur à la création";
                return false;
            }else{
                qDebug() << "Tag inséré";
                QSqlQuery myQuery;
                //On ccrée aussi une association intéraction-tag
                if (myQuery.exec("SELECT MAX(idTag) FROM Tags"))
                    if(myQuery.next())
                        createAssocTI(myQuery.value(0).toInt());
            }
        }
    }
    return true;
}

//creation d'une association inter-tag
bool QSQLData::createAssocTI(int idTag) const
{
    if(dbOuverte == true){
        QSqlQuery qIDInter;
        //on récupère la dernière valeur d'idIntéraction (= la dernière entrée)
        if (qIDInter.exec("SELECT MAX(idInteraction) FROM Interactions"))
            if(qIDInter.next()){

                int idInter = qIDInter.value(0).toInt();

                QSqlQuery query;
                //On insère l'association
                 query.prepare("INSERT INTO AssociationTI (idTag, idInter) VALUES (:t, :i)");
                 query.bindValue(":t", idTag);
                 query.bindValue(":i", idInter);

                 if(!query.exec())
                 {
                     qDebug() << "Erreur à la création de l'association";
                     return false;
                 }else{
                     qDebug() << "Association insérée";
                 }
             }

    }
    return true;
}

//Suppression d'un tag
bool QSQLData::deleteTag(const Tag & t) const
{
    if(dbOuverte == true)
    {
        QSqlQuery query;

        //on récupère l'id du tag
        query.prepare("SELECT idTag FROM Tags WHERE dateTag=:d AND contenuTag=:c;");

        query.bindValue(":d", QString::fromStdString(t.getDateTag().toStringDateAbb()));
        query.bindValue(":c", QString::fromStdString(t.getContenuTag()));

        if(!query.exec())
        {
            qDebug() << "Erreur à la suppression du Tag";
            return false;
        }else{
            if(query.next())
            {
                qDebug() << "Tag trouvé";
                std::string id = query.value(0).toString().toStdString();

                //on le supprime
                QSqlQuery querySuppTag;
                querySuppTag.prepare("DELETE FROM Tags WHERE idTag=:i");
                querySuppTag.bindValue(":i", QString::fromStdString(id));

                if(!querySuppTag.exec())
                    qDebug() << "Tag supprimé";

                //on supprime également l'association intéraction-tag
                QSqlQuery querySuppAssoc;
                querySuppAssoc.prepare("DELETE FROM AssociationTI WHERE idTag=:i");
                querySuppAssoc.bindValue(":i", QString::fromStdString(id));

                if(!querySuppAssoc.exec())
                    qDebug() << "Association supprimée";
            }
            else{
                qDebug() << "Tag non trouvé";
            }
        }
    }
    return true;
}

//récupération des tags d'un contact
bool QSQLData::getTags(const Contact & c) const
{
    QStringList l;
    if(dbOuverte == true)
    {
        //on cherche les tags du contact
        QSqlQuery query;
        query.prepare("SELECT dateTag, contenuTag FROM Tags, AssociationTI, Interactions, Contacts WHERE nom=:n and prenom=:p and entreprise=:e and Contacts.idContact = Interactions.idContact and Interactions.idInteraction = AssociationTI.idInter and AssociationTI.idTag = Tags.idTag;");
        //les valeurs de la requête sont extraites du contact en paramètre
        query.bindValue(":n", QString::fromStdString(c.getNom()));
        query.bindValue(":p", QString::fromStdString(c.getPrenom()));
        query.bindValue(":e", QString::fromStdString(c.getEntreprise()));

        if(!query.exec())
        {
            qDebug() << "Impossible d'exécuter la requête";
            return false;
        }else{

            qDebug() << "Requête exécutée";
            GestionTag *gt=new GestionTag();

            //on retourne la liste des tags trouvés sous forme d'une instance GestionTag
            while(query.next())
            {
                Tag* t = new Tag();
                t->setDateTag(query.value(0).toString().toStdString());
                t->setContenuTag(query.value(1).toString().toStdString());
                gt->addTag(*t);
            }
            //on renvoit cette liste de tags
            emit envoieListTags(gt);
        }
    }
    return true;
}




