#ifndef CREAINTER_H
#define CREAINTER_H

#include <QWidget>
#include <interaction.h>
#include <contact.h>
#include <QStringList>

namespace Ui {
class creaInter;
}

class creaInter : public QWidget
{
    Q_OBJECT

public:
    explicit creaInter(QWidget *parent = nullptr);
    ~creaInter();

    void ajoutInter();
    void champsObli();

    //Initialisation de la ComboBox
    void setQstList(QStringList);

private:
    Ui::creaInter *ui;
    Interaction* i;
    Contact *c;

signals:
    void sigAddInter(Interaction&, Contact&);
    void majAffInter();

private slots:
    void on_bValider_clicked();
};

#endif // CREAINTER_H
