#include "editcontact.h"
#include "ui_editcontact.h"
#include "QMessageBox"
#include "contact.h"
#include "stdio.h"
#include "iostream"

editContact::editContact(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::editContact)
{
    ui->setupUi(this);
    cUp = new Contact();
}

//Constructeur
editContact::~editContact()
{
    delete ui;
    delete cUp;
    delete c;
}

//Assesseurs
void editContact::setC(Contact *const cP)
{   c = cP; }

void editContact::setCup(Contact *const cPup)
{   cUp = cPup; }

Contact* editContact::getC() const
{   return c; }

Contact* editContact::getCup() const
{   return cUp; }


//Appui sur le bouton Annuler :
void editContact::on_bAnnuler_clicked()
{
    //Fermeture de la fenêtre :
    close();
}

//Appui sur le bouton valider :
void editContact::on_bValider_clicked()
{
    //Si les champs requis sont remplis (Nom, prénom et entreprise)
    if(!ui->leNom->text().isEmpty() && !ui->lePrenom->text().isEmpty() && !ui->leEntreprise->text().isEmpty())
    {
        //mise à jour :
        updateContact();
    }
    //Sinon : erreur
    else
    {
        champsObli();
    }

}

//remplissage des champs à l'ouverture
void editContact::remplir(Contact & cS)
{
    setC(&cS);
    ui->leNom->setText(QString::fromStdString(c->getNom()));
    ui->lePrenom->setText(QString::fromStdString(c->getPrenom()));
    ui->leEntreprise->setText(QString::fromStdString(c->getEntreprise()));
    ui->leMail->setText(QString::fromStdString(c->getMail()));
    ui->lepPhoto->setText(QString::fromStdString(c->getUriPhoto()));
    ui->leTel->setText(QString::fromStdString(c->getStTelephone()));
}

//Si les champs requis ne sont pas remplis :
void editContact::champsObli()
{
    //affichage d'un message d'erreur :
    QMessageBox msgBox;
    msgBox.setText("Erreur : Le nom, prénom et entreprise sont des champs obligatoires.");
    msgBox.exec();
}

//Envoi du contact à la BDD
void editContact::updateContact()
{
    //Initialisation du contact cUp d'aprèsles champs du formulaire
    cUp->setNom(ui->leNom->text().toStdString());
    cUp->setPrenom(ui->lePrenom->text().toStdString());
    cUp->setEntreprise(ui->leEntreprise->text().toStdString());
    cUp->setMail(ui->leMail->text().toStdString());
    cUp->setUriPhoto(ui->lepPhoto->text().toStdString());
    cUp->setTelephoneFromStd(ui->leTel->text().toStdString());

    //envoie de la demande de mise à jour à la BDD
    emit sigUpdateContact(*c, *cUp);

    //fermeture
    close();
}
