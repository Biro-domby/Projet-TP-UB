#include "intergestion.h"

InterGestion::InterGestion()
{

}
