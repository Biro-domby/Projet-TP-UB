#ifndef CONTACT_H
#define CONTACT_H

//#include <QObject>
#include <ctime>
#include <string>
#include <list>
#include <interaction.h>
#include <gestioninter.h>


class Contact
{

private :
    std::string nom;
    std::string prenom;
    std::string entreprise;
    std::string mail;
    std::list<unsigned> telephone;
    std::string  uriPhoto;
    Date dateCreation;
    Date derniereModif;
    GestionInter listInteractions;

public :
    //constructeurs
    Contact();
    Contact(const std::string, const std::string, const std::string);
    Contact(std::string);

    void initFromString(std::string);

    //destructeur
    ~Contact();

    //assesseurs
    void setNom(const std::string);
    std::string getNom() const;
    void setPrenom(const std::string);
    std::string getPrenom() const;
    void setEntreprise(const std::string);
    std::string getEntreprise() const;
    void setMail(const std::string);
    std::string getMail() const;
    void setTelephone(const std::list<unsigned>);
    void setTelephoneFromStd(const std::string);
    std::list<unsigned> getTelephone() const;
    std::string getStTelephone() const;
    void setUriPhoto(const std::string);
    std::string getUriPhoto() const;
    void setDate(const Date &);
    Date getDate() const;
    void setDernModif(const Date &s);
    Date getDernModif() const;

    bool isNull();

    //opérateur de comparaison
    bool operator==(const Contact &);

    //affichage
    friend std::ostream& operator<<(std::ostream &,const Contact &);

    std::string toString();
    std::string toItemTxt();

};

#endif // CONTACT_H
