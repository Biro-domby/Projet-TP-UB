#ifndef TODO_H
#define TODO_H

#include <ctime>
#include <string>

class Todo
{
private:
    std::string contenu;
    tm* date;
public:
    Todo();
    Todo(const std::string &);
    Todo(const std::string &, const tm &);

    ~Todo();

    //accesseurs
    tm getDate() const;
    std::string getContenu() const;

    //mutateurs
    void setDate(const tm &);
    void setContenu(const std::string &);

    friend std::ostream& operator<<(std::ostream &, const Todo &);

};

#endif // TODO_H
