#include <string>
#include <iostream>
#include <sstream>
#include <tag.h>
#include <gestiontag.h>
#include <gestioncontact.h>
#include <contact.h>
#include <date.h>
#include <gestioninter.h>
#include <interaction.h>


//constructeurs
GestionInter::GestionInter()
{    std::list<Interaction> interList; }

GestionInter::GestionInter(std::list<Interaction> liste)
{
    std::list<Interaction> contactLst;
    setInterList(liste);
}

//destructeur
GestionInter::~GestionInter()
{    interList.clear(); }

//assesseurs
void GestionInter::setInterList(std::list<Interaction> liste)
{
    interList = liste;
}

std::list<Interaction> GestionInter::getInterList()
{    return interList; }


//gestion des interactions

//ajout d'une intéraction dans la liste
void GestionInter::addInter(Interaction i)
{    interList.push_back(i); }

//tri des intéractions par ordre décroissant d'urgence
void GestionInter::trier()
{
    interList.sort();
    interList.reverse();
}


//affichage

std::string GestionInter::toString() const
{
    std::string s;
    for (auto&& i : interList){
        s+= "INTERACTION :\n" + i.getDate().toStringDate() + " | " + i.getContenu() + "\n";
    }
    return s;
}

QStringList GestionInter::toItemList() //pour l'affichage dans les QWidgetList
{
    QStringList l;
    for (auto&& i : interList){
        QString s;
        s = QString::fromStdString(i.toItemTxt());
        l<<s;
    }
    return l;
}

std::ostream& operator<<(std::ostream & os, const GestionInter & gsInter)
{

    for (auto&& i : gsInter.interList){
        os << "INTERACTION :\n" << i.getDate().toStringDate() << " | " << i.getContenu() << "\n";
    }
    return os;
}
