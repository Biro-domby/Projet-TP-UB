#include "creainter.h"
#include "ui_creainter.h"
#include "interaction.h"
#include "contact.h"
#include "QMessageBox"
#include "stdio.h"
#include "iostream"

//Constructeur
creaInter::creaInter(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::creaInter)
{
    ui->setupUi(this);
    i = new Interaction();
    c = new Contact();
}

//Destructeur
creaInter::~creaInter()
{
    delete ui;
}

//Initialisation de la ComboBox
void creaInter::setQstList(QStringList l)
{
    ui->comboContact->addItems(l);
}

//A l'appui sur le bouton Valider
void creaInter::on_bValider_clicked()
{
    //Si aucun contact n'est sélectionné ou que le contenu de l'intéraction n'est pas rempli
    if(ui->comboContact->currentIndex()==-1 || ui->plainTextEdit->toPlainText().isEmpty())
        //Message d'erreur
        champsObli();
    else
        //envoi à la BDD
        ajoutInter();
}

//Quand l'intéraction n'est pas bien remplie à la validation :
void creaInter::champsObli()
{
    //Affichage d'un message pour l'utilisateur
    QMessageBox msgBox;
    msgBox.setText("Sélectionnez un contact et remplissez le contenu de l'intéraction.");
    msgBox.exec();
}

//Sinon, paramétrage pour l'envoi à la BDD
void creaInter::ajoutInter()
{
    //La date de l'intéraction est celle sélectionnée dans le calendrier :
    QDate d = ui->calendarWidget->selectedDate();
    Date date(d.day(), d.month(), d.year());
    i->setDate(date);

    //Contenu depuis le plainTextEdit
    i->setContenu(ui->plainTextEdit->toPlainText().toStdString());

    //Rempli la liste de tags
    i->initFromString(ui->plainTextEdit->toPlainText().toStdString());

    //On récupère le contact
    std::string contactSt = ui->comboContact->currentText().toStdString();

    std::size_t found = contactSt.find(" ");
    c->setNom(contactSt.substr(0,found));
    contactSt = contactSt.substr(found+1);

    found = contactSt.find(", ");
    c->setPrenom(contactSt.substr(0,found));
    contactSt = contactSt.substr(found+2);

    c->setEntreprise(contactSt);

    //envoie de la demande de création à la BDD
    emit sigAddInter(*i, *c);
    //mise à jour de la liste d'intéractions dans mainWIndow
    emit majAffInter();

    //fermeture
    close();
}
