#include "formulairerecherche.h"
#include "date.h"
#include "contact.h"

//Constructeur
formulaireRecherche::formulaireRecherche()
{    contact = new Contact(); }


//Assesseurs

void formulaireRecherche::setContact(Contact & c)
{    contact = &c; }

Contact* formulaireRecherche::getContact()
{    return contact; }

Date formulaireRecherche::getCrea1()
{    return crea1;  }

Date formulaireRecherche::getCrea2()
{    return crea2;  }

Date formulaireRecherche::getModif1()
{    return modif1; }

Date formulaireRecherche::getModif2()
{    return modif2; }

void formulaireRecherche::setCrea1(Date d)
{    crea1 = d; }

void formulaireRecherche::setCrea2(Date d)
{    crea2 = d; }

void formulaireRecherche::setModif1(Date d)
{    modif1 = d; }

void formulaireRecherche::setModif2(Date d)
{    modif2 = d; }


//Méthodes :

void formulaireRecherche::setNullCrea1()
{   crea1.setDateVide(); }

void formulaireRecherche::setNullCrea2()
{   crea2.setDateVide(); }

void formulaireRecherche::setNullModif1()
{   modif1.setDateVide(); }

void formulaireRecherche::setNullModif2()
{   modif2.setDateVide(); }
