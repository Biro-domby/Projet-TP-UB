#ifndef TAG_H
#define TAG_H

#include <string>
#include <ctime>
#include <date.h>


class Tag
{
private:
    std::string contenuTag;
    Date dateTag;

public:
    //constructeurs
    Tag();
    Tag(const std::string &);
    Tag(const std::string &, const Date &);

    //destructeur
    ~Tag();

    //assesseurs
    void setContenuTag(const std::string &);
    void setDateTag(const Date &);
    std::string getContenuTag() const;
    Date getDateTag() const;

    //pour initialiser un tag à partir du texte affiché dans les itemlist
    void initFromItemTag(std::string);

    std::string toString() const;
    std::string toItemTxt();

    friend std::ostream& operator<<(std::ostream &, const Tag &);
};

#endif // TAG_H
