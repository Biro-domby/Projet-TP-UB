#ifndef GESTIONTAG_H
#define GESTIONTAG_H

#include <list>
#include <string>
#include <tag.h>
#include <QStringList>

class GestionTag
{
private :
    std::list<Tag> tagList;

public:
    //constructeurs
    GestionTag();
    GestionTag(std::list<Tag>);

    //destructeur
    ~GestionTag();

    //gestion des tags
    void addTag(Tag);

    //assesseurs
    std::list<Tag> getTagList();
    void setTagList(std::list<Tag>);

    //méthodes d'affichage
    std::string toString() const;
    QStringList toItemList();

    friend std::ostream& operator<<(std::ostream &, const GestionTag &);

};

#endif // GESTIONTAG_H
