#include<iostream>
using namespace std;
#include<cstdlib>

void genere(int n, int m, int a[][2])
{
  int x,y;
  srand(time(NULL));
  for(int i=0;i<m;i++)
  {
    x=rand()%n; y=rand()%n;
    a[i][0]=x; a[i][1]=y;
  }
}

int composantes(int n, int m, int a[][2], int co[])
{
  int c,x,y;
  for(int i=0;i<n;i++) co[i]=i;
  for(int j=0;j<m;j++)
  {
     x=a[j][0]; y=a[j][1];             
     if(co[x]!=co[y])
     {
       c=co[y];
       for(int k=0;k<n;k++)
         if(co[k]==c) co[k]=co[x];
     }
  }
}  



void tailles(int n, int m, int t[], int co[])
{
  int cpt=0;
  for(int i=0;i<n;i++)
   t[i]=0;
  for(int i=0;i<n;i++)
   t[co[i]]++;
}

void tri(int n, int t[])
{
  int i   = 0; 
  int j   = 0; 
  int tmp = 0; 
  int en_desordre = 1; 
        
  for(i = 0 ; (i < n) && en_desordre; i++)
  {
      en_desordre = 0;
      for(j = 1 ; j < n - i ; j++)
      {
        if(t[j] < t[j-1])
        {
          tmp = t[j-1];
          t[j-1] = t[j];
          t[j] = tmp;
          en_desordre = 1;
        }
      }
   }
}
  
void affiche(int n, int t[])
{
  int i=0,a,cpt; 
  while((i<n) && (t[i]==0)) i++;
  while(i<n)
  {
    cpt=1;a=t[i];
    while((i++<n-1)&&(t[i]==a)) cpt++;
    cout << "Il y a " << cpt << " composantes à " << a << " sommets"<< endl;
  }
}


int main()
{
int n,m;
cout << "nb de sommets"<< endl;
  cin >> n;
 cout << "nb d'aretes"<< endl;
cin >> m;
  int arete[m][2], comp[n];
  int taille[n];
  genere(n,m,arete);
  composantes(n,m,arete,comp);
  tailles(n,m,taille,comp);
  tri(n,taille);
  affiche(n,taille);
  cin >> n;
  return 0;
}
