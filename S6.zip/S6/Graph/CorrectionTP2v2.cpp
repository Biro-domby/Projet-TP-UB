#include <cstdlib>
#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>

using namespace std;

const int MAX_INT = 0x7FFFFFFF;
const int n=400;
const int dmax=100;
vector<int> voisin[n];
int point[n][2];
int arbre[n-1][2];
int pere[n];


void genere(int n, int p[][2])
{
  int x,y;
  srand(time(NULL));
  for(int i=0;i<n;i++)
  {
    x=rand()%612; y=rand()%792;
    p[i][0]=x; p[i][1]=y;
  }
}

void affichegraphe(int n,int d, int sommet[][2])       
  {ofstream output;             // Cree le fichier Graphe.ps qui affiche le graphe.
  output.open("Graphe.ps",ios::out);
  output << "%!PS-Adobe-3.0" << endl;
  output << endl;  
  for(int i=0;i<n;i++)
    {output << sommet[i][0] << " " << sommet[i][1] << " 1 0 360 arc" <<endl;
    output << "0 setgray" <<endl;
    output << "fill" <<endl;
    output << "stroke"<<endl;
    output << endl;
    }
  output << endl;
  for(int i=0;i<n-1;i++)
    {for (int j=i+1 ;j<n;j++)
      if ((point[i][0]-point[j][0])*(point[i][0]-point[j][0])+(point[i][1]-point[j][1])*(point[i][1]-point[j][1])<d*d)
      {output << sommet[i][0] << " " << sommet[i][1] 
      << " moveto" << endl;
      output << sommet[j][0] << " " << sommet[j][1] 
      << " lineto" << endl;
      output << "stroke" << endl;
      output << endl;
      }
    }
  }

void affichearbre(int n, int k, int point[][2], int arbre[][2])  
// Cree le fichier Arbre.ps qui affiche l'arbre.
{ofstream output;                           
 output.open("Arbre.ps",ios::out);
 output << "%!PS-Adobe-3.0" << endl;
 output << "%%BoundingBox: 0 0 612 792" << endl;
 output << endl;  
 for(int i=0;i<n;i++)
   {output << point[i][0] << " " << point[i][1] << " 1 0 360 arc" <<endl;
   output << "0 setgray" <<endl;
   output << "fill" <<endl;
   output << "stroke"<<endl;
   output << endl;
   }
 output << endl;
 for(int i=0;i<k;i++)
   {output << point[arbre[i][0]][0] << " " << point[arbre[i][0]][1] 
	   << " moveto" << endl;
   output << point[arbre[i][1]][0] << " " << point[arbre[i][1]][1] 
	  << " lineto" << endl;
   output << "stroke" << endl;
   output << endl;
   }
output.close();
}


void voisins(int n, int d, int point[][2])
{
  for(int i=0; i<n; i++)
  {
    voisin[i].assign(0,0);
    for(int j=0;j<n;j++)
     if ((i!=j) && ((point[i][0]-point[j][0])*(point[i][0]-point[j][0])+(point[i][1]-point[j][1])*(point[i][1]-point[j][1])<d*d))
       voisin[i].push_back(j);
  }
}


int distMin(int n, int d[], bool vis[])
{
    int i,pos, min;
    min=MAX_INT;
    for(i=0;i<n;i++)
      if((!vis[i]) && (d[i]<min)) {min=d[i]; pos=i;}
    if(min==MAX_INT) return -1; else return pos;
}

void dijkstra(int n, vector<int> v[],int pere[])
{
     int dist[n];
     int u, alt,nb=0;
     
     bool visite[n];
     vector <int>::iterator Iter;
     for(int j=1;j<n;j++)
       {dist[j]=MAX_INT; pere[j]=-1;visite[j]=false;}
     dist[0]=0; pere[0]=0; visite[0]=false;
     while(nb<n)   
     {
       nb++;
       u=distMin(n,dist,visite);
       if(u==-1) break;
       visite[u]=true;
       
       for(Iter=v[u].begin(); Iter<v[u].end(); Iter++)
       {
         alt=dist[u]+ max((point[u][0]-point[*Iter][0]),(point[u][1]-point[*Iter][1])); 
         if(alt< dist[*Iter])
         {
           dist[*Iter]=alt;
           pere[*Iter]=u;
         }
       }
     }
}

int construitarbre(int n, int a[][2], int p[])
{
    int cpt=0;
    for(int i=1;i<n-1;i++)
      if(p[i]!=-1)
        {a[cpt][0]=i; a[cpt][1]=p[i]; cpt++;}
    return (cpt+1);
}

int main()
{
  int k;   
  genere(n,point);
  affichegraphe(n,dmax,point);
  voisins(n,dmax,point);
  dijkstra(n,voisin, pere);
  //for(int i=0;i<n;i++)
    //cout << "pere de " << i << " : " << pere[i] << endl;
  k=construitarbre(n,arbre,pere);
  affichearbre(n, k, point, arbre);
  return 0;
}
